# Angad Ads – Website

Vite + React + Tailwind v4 static site.

    npm install
    npm run dev      # local: http://localhost:3000
    npm run build    # production build -> dist/

Deploy: Vercel / Netlify / Cloudflare Pages — Build command `npm run build`, Output dir `dist`.
Screenshots: `public/proof/`, data: `src/data/proofs.ts`. Meta Pixel ID is in `index.html`.
