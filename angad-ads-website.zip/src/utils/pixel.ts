/**
 * Meta Pixel Tracking Utility
 * Pixel ID: 1587187573188531
 */

declare global {
  interface Window {
    fbq?: (...args: any[]) => void;
    _fbq?: any;
  }
}

/**
 * Track standard or custom Meta Pixel events safely
 */
export const trackPixelEvent = (
  eventName: string,
  params?: Record<string, any>,
  isCustom = false
) => {
  if (typeof window !== 'undefined' && typeof window.fbq === 'function') {
    try {
      if (isCustom) {
        window.fbq('trackCustom', eventName, params);
      } else {
        window.fbq('track', eventName, params);
      }
    } catch (err) {
      console.warn('Meta Pixel tracking error:', err);
    }
  }
};

/**
 * Track Telegram link clicks
 * Fires 'Contact' and 'Lead' standard events
 */
export const trackTelegramClick = (source: string, additionalData?: Record<string, any>) => {
  trackPixelEvent('Contact', {
    channel: 'Telegram',
    source: source,
    destination: 'https://t.me/Angad_ads',
    ...additionalData,
  });

  trackPixelEvent('Lead', {
    content_name: `Telegram Inquiry - ${source}`,
    content_category: 'Inquiry',
    currency: 'INR',
    ...additionalData,
  });
};

/**
 * Track Direct Call button clicks
 * Fires 'Contact' and 'Lead' standard events
 */
export const trackPhoneCall = (
  phoneNumber: string,
  lineType: 'Primary' | 'Secondary',
  source: string
) => {
  trackPixelEvent('Contact', {
    channel: 'Direct Phone Call',
    phone_line: lineType,
    phone_number: phoneNumber,
    source: source,
  });

  trackPixelEvent('Lead', {
    content_name: `Phone Call - ${lineType} (${phoneNumber}) - ${source}`,
    content_category: 'Inquiry',
    currency: 'INR',
  });
};

/**
 * Track custom user intention events
 */
export const trackIntentEvent = (intentType: 'Training' | 'Setup' | 'Pricing' | 'LeadGen', source: string) => {
  trackPixelEvent('Contact', {
    intent: intentType,
    source: source,
  });
};
