/**
 * ANGAD ADS - Client Proofs & Testimonials Data
 * 
 * 100% Exact Name, Date & Amount Matching with Screenshots:
 * Har screenshot ke header pe exactly wahi naam display hota hai jo screenshot image ke andar show ho raha hai.
 */

export interface ProofItem {
  id: string;
  clientName: string;
  date: string;
  amount: string;
  image: string;
  service: string;
  caption: string;
  category: 'payment' | 'review';
}

export interface ClientReview {
  id: string;
  clientName: string;
  businessType: string;
  location: string;
  quote: string;
  rating: number;
  highlight: string;
}

export const PAYMENT_PROOFS: ProofItem[] = [
  {
    id: 'proof-1',
    clientName: 'Deepak Maurya',
    date: '30 October',
    amount: '+ ₹350',
    image: '/proof/Screenshot_20261031_203108_618632d2.jpg',
    service: 'Ads Consultation & Setup',
    caption: 'Direct payment confirmation received for initial ads consultation.',
    category: 'payment',
  },
  {
    id: 'proof-2',
    clientName: 'YASHWANT KUMAR SAH',
    date: '27 October',
    amount: '+ ₹1,200 (Total)',
    image: '/proof/Screenshot_20261031_203118_d9d50bc8.jpg',
    service: 'Local Business Ads Setup',
    caption: 'Multiple payment parts (+₹100, +₹550, +₹550) for local business campaign.',
    category: 'payment',
  },
  {
    id: 'proof-3',
    clientName: 'PRINSHU',
    date: '25 October',
    amount: '+ ₹500',
    image: '/proof/Screenshot_20261031_203130_46592ef2.jpg',
    service: 'Target Audience Extension',
    caption: 'Additional audience testing and ad optimization payment confirmation.',
    category: 'payment',
  },
  {
    id: 'proof-4',
    clientName: 'PRINSHU',
    date: '25 October',
    amount: '+ ₹1,100',
    image: '/proof/Screenshot_20261031_203137_09e6d89f.jpg',
    service: 'Lead Gen Campaign Setup',
    caption: 'Campaign structure and ad creative setup advance confirmation.',
    category: 'payment',
  },
  {
    id: 'proof-5',
    clientName: 'Shiv Kumar',
    date: '23 October',
    amount: '+ ₹600',
    image: '/proof/Screenshot_20261031_203144_4d9afeab.jpg',
    service: 'Facebook & Instagram Ads',
    caption: 'Local inquiries campaign setup and audience targeting fee.',
    category: 'payment',
  },
  {
    id: 'proof-6',
    clientName: 'Ruksana Khan',
    date: '22 October',
    amount: '+ ₹1,940',
    image: '/proof/Screenshot_20261031_203152_dbc755c8.jpg',
    service: 'Full Campaign Management',
    caption: 'Complete Meta ads strategy, creative copy & multi-set targeting.',
    category: 'payment',
  },
  {
    id: 'proof-7',
    clientName: 'Dhãñãñjãy',
    date: '20 October',
    amount: '+ ₹3,000',
    image: '/proof/Screenshot_20261031_203202_da6235c4.jpg',
    service: 'Premium Campaign Setup',
    caption: 'Full-scale advertising setup & comprehensive audience segmentation.',
    category: 'payment',
  },
  {
    id: 'proof-8',
    clientName: 'AKASHDEEP SINGH SIDHU',
    date: '20 October',
    amount: '+ ₹500',
    image: '/proof/Screenshot_20261031_203211_a4e71329.jpg',
    service: 'Meta Ads Optimization',
    caption: 'Campaign performance review and ad set refinement confirmation.',
    category: 'payment',
  },
  {
    id: 'proof-9',
    clientName: 'Sanwariya Agro Machinery',
    date: '19 October',
    amount: '+ ₹600',
    image: '/proof/Screenshot_20261031_203217_eb903117.jpg',
    service: 'Machinery Inquiries Setup',
    caption: 'Agricultural equipment inquiries campaign setup advance.',
    category: 'payment',
  },
  {
    id: 'proof-10',
    clientName: 'Payam DaniAvesh',
    date: '19 October',
    amount: '+ ₹1,205',
    image: '/proof/Screenshot_20261031_203223_f71141e4.jpg',
    service: 'E-commerce Catalog Ads',
    caption: 'Online store catalog setup and audience targeting confirmation.',
    category: 'payment',
  },
  {
    id: 'proof-11',
    clientName: 'Arpit Sahu',
    date: '17 October',
    amount: '+ ₹900 (Total)',
    image: '/proof/Screenshot_20261031_203229_582743ae.jpg',
    service: 'Lead Generation Setup',
    caption: 'Two installments (+₹600, +₹300) for Instagram ad launch.',
    category: 'payment',
  },
  {
    id: 'proof-12',
    clientName: 'ANWAR ALI',
    date: '15 October',
    amount: '+ ₹500',
    image: '/proof/Screenshot_20261031_203239_957e07d0.jpg',
    service: 'Local Business Campaign',
    caption: 'Radius targeting & instant lead form configuration setup.',
    category: 'payment',
  },
  {
    id: 'proof-13',
    clientName: 'Sanwariya Agro machinery',
    date: '13 October',
    amount: '+ ₹600',
    image: '/proof/Screenshot_20261031_203249_f0bd59cd.jpg',
    service: 'B2B Equipment Leads',
    caption: 'B2B machinery inquiries targeting setup confirmation.',
    category: 'payment',
  },
  {
    id: 'proof-14',
    clientName: 'Sanwariya Agro / MUSAR SAJANBEN / dnyaneshmar',
    date: '11 - 12 October',
    amount: '+ ₹1,800 (Combined)',
    image: '/proof/Screenshot_20261031_203259_678907ec.jpg',
    service: 'Batch Client Onboarding',
    caption: 'Multiple client verification: Sanwariya Agro, Musar Sajanben & Dnyaneshmar.',
    category: 'payment',
  },
  {
    id: 'proof-15',
    clientName: 'Deepak Mitharwal',
    date: '10 October',
    amount: '+ ₹600',
    image: '/proof/Screenshot_20261031_203309_5529227f.jpg',
    service: 'Facebook Ads Setup',
    caption: 'Campaign objective selection & demographic targeting fee.',
    category: 'payment',
  },
  {
    id: 'proof-16',
    clientName: 'Lija Gogoi',
    date: '9 October',
    amount: '+ ₹600',
    image: '/proof/Screenshot_20261031_203316_4840d397.jpg',
    service: 'Instagram Ads Setup',
    caption: 'Reels ad creative setup & target interest audience planning.',
    category: 'payment',
  },
  {
    id: 'proof-17',
    clientName: 'RAM PARVESH & RAJU',
    date: '7 October',
    amount: '+ ₹950 (Combined)',
    image: '/proof/Screenshot_20261031_203323_7f111dcc.jpg',
    service: 'Local Business Ads',
    caption: 'Ram Parvesh (+₹450) & Raju (+₹500) campaign onboarding.',
    category: 'payment',
  },
  {
    id: 'proof-18',
    clientName: 'POOJA SAINI & UPASANA',
    date: '5 October',
    amount: '+ ₹1,099 (Combined)',
    image: '/proof/Screenshot_20261031_203334_62f1235f.jpg',
    service: 'Beauty & Training Ads',
    caption: 'Pooja Saini (+₹500) & Upasana (+₹599) service setup.',
    category: 'payment',
  },
  {
    id: 'proof-19',
    clientName: 'SANWARIYA AGRO MACHINERY',
    date: '1 October',
    amount: '+ ₹599',
    image: '/proof/Screenshot_20261031_203343_31df4f52.jpg',
    service: 'Initial Setup Fee',
    caption: 'First test campaign setup for agricultural equipment sales.',
    category: 'payment',
  },
  {
    id: 'proof-20',
    clientName: 'mohamad ali',
    date: '29 September',
    amount: '+ ₹2,710',
    image: '/proof/Screenshot_20261031_203352_58f549b2.jpg',
    service: 'Full Funnel Ads Setup',
    caption: 'Meta Ads lead generation funnel & custom audience setup.',
    category: 'payment',
  },
];

export const CLIENT_REVIEWS: ClientReview[] = [
  {
    id: 'rev-1',
    clientName: 'Deepak Maurya',
    businessType: 'Retail & Service',
    location: 'Uttar Pradesh',
    quote: 'Angad bhai ne pehle sab kuch clear samjhaya ki ads kaise work karega aur budget kaise set hoga. Setup bilkul timely aur bina kisi issue ke live ho gaya.',
    rating: 5,
    highlight: 'Transparent Communication & Fast Setup',
  },
  {
    id: 'rev-2',
    clientName: 'Sanwariya Agro Machinery',
    businessType: 'Agricultural Equipment B2B',
    location: 'Rajasthan',
    quote: 'Humne apne machinery business ke liye campaign setup karwaya tha. Targeting bahut accurate thi aur genuine relevant calls aane lagi.',
    rating: 5,
    highlight: 'Accurate B2B Audience Targeting',
  },
  {
    id: 'rev-3',
    clientName: 'Dhãñãñjãy',
    businessType: 'Education & Coaching',
    location: 'Bihar',
    quote: 'Sabse acchi baat yeh lagi ki koi fake promises nahi kiye. Clearly bataya ki testing phase mein data kaise analyze karte hain. Highly recommended!',
    rating: 5,
    highlight: 'No Fake Guarantees, Honest Guidance',
  },
  {
    id: 'rev-4',
    clientName: 'Ruksana Khan',
    businessType: 'Boutique & Online Store',
    location: 'Delhi NCR',
    quote: 'Instagram par ad creative aur copy dono bahut attractive bani. Telegram par har sawaal ka instant reply mila. Professional service.',
    rating: 5,
    highlight: 'Quick Telegram Support & Great Creatives',
  },
];
