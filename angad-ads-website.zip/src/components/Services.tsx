import React from 'react';
import { Layers, GraduationCap, Users, Smartphone, TrendingUp, HelpCircle, Send, ArrowUpRight } from 'lucide-react';
import { trackTelegramClick } from '../utils/pixel';

interface ServiceItem {
  id: string;
  icon: React.ReactNode;
  title: string;
  description: string;
  tag: string;
}

export const Services: React.FC = () => {
  const services: ServiceItem[] = [
    {
      id: 'meta-ads-setup',
      icon: <Layers className="w-6 h-6 text-blue-400" />,
      title: 'Meta Ads Setup Karwao',
      description: 'Facebook aur Instagram par aapke business ke liye campaign setup karwane ke liye contact karein.',
      tag: 'Done-For-You Setup',
    },
    {
      id: 'meta-ads-training',
      icon: <GraduationCap className="w-6 h-6 text-violet-400" />,
      title: 'Meta Ads Chalana Seekho',
      description: 'Khud se ads chalana, campaign structure samajhna aur basic targeting seekhne ke liye training aur guidance lein.',
      tag: '1-on-1 Training & Guidance',
    },
    {
      id: 'lead-generation-ads',
      icon: <Users className="w-6 h-6 text-emerald-400" />,
      title: 'Lead Generation Ads',
      description: 'Apne business ke liye relevant enquiries lane ke purpose se lead generation campaign plan karwayein.',
      tag: 'High-Intent Inquiries',
    },
    {
      id: 'fb-insta-ads',
      icon: <Smartphone className="w-6 h-6 text-cyan-400" />,
      title: 'Facebook & Instagram Ads',
      description: 'Apne business goals aur advertising budget ke according campaign strategy discuss karein.',
      tag: 'Platform Strategy',
    },
    {
      id: 'campaign-optimization',
      icon: <TrendingUp className="w-6 h-6 text-amber-400" />,
      title: 'Campaign Optimization',
      description: 'Existing campaign ko review karwayein aur performance improve karne ke possible options samjhein.',
      tag: 'Performance Audit',
    },
    {
      id: 'personal-guidance',
      icon: <HelpCircle className="w-6 h-6 text-blue-400" />,
      title: 'Personal Guidance',
      description: 'Meta Ads setup, targeting, campaign planning ya advertising se related koi bhi sawal ho, apni requirements share karein.',
      tag: 'Direct Q&A Support',
    },
  ];

  return (
    <section id="services" className="py-20 bg-transparent relative z-10 cinematic-section-reveal">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-semibold tracking-wider uppercase text-blue-400 bg-blue-950/50 border border-blue-500/20 px-3 py-1 rounded-md inline-block mb-3">
            OUR CORE OFFERINGS
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mb-4 text-balance">
            Aapko Jo Help Chahiye, Humse Discuss Karein
          </h2>
          <p className="text-base sm:text-lg text-slate-300 leading-relaxed text-balance">
            Chahe aap apne business ke liye ads setup karwana chahein ya khud Meta Ads chalana seekhna chahein, hum aapki requirements ke according suitable plan provide karte hain.
          </p>
        </div>

        {/* 6 Services Grid: 3 cols desktop, 2 cols tablet, 1 col mobile */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((item, idx) => (
            <div
              key={item.id}
              className="group rounded-2xl glass-card p-6 sm:p-7 glass-card-hover flex flex-col justify-between relative overflow-hidden"
            >
              {/* Card top gradient accent bar on hover */}
              <div className="absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r from-blue-500 via-indigo-500 to-violet-500 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              
              <div>
                {/* Header row with Icon and index */}
                <div className="flex items-center justify-between mb-5">
                  <div className="w-12 h-12 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center group-hover:scale-105 group-hover:border-blue-500/40 transition-all duration-200">
                    {item.icon}
                  </div>
                  <span className="text-xs font-mono text-slate-500 tabular-nums">
                    0{idx + 1}
                  </span>
                </div>

                {/* Service Title */}
                <h3 className="text-xl font-bold text-white mb-2.5 group-hover:text-blue-300 transition-colors">
                  {item.title}
                </h3>

                {/* Hinglish Description */}
                <p className="text-sm text-slate-300/90 leading-relaxed mb-6">
                  {item.description}
                </p>
              </div>

              {/* Card CTA Footer */}
              <div className="pt-4 border-t border-slate-800/80 flex items-center justify-between">
                <span className="text-xs text-slate-400 font-medium">
                  {item.tag}
                </span>

                <a
                  href="https://t.me/Angad_ads"
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => trackTelegramClick(`Service Card: ${item.title}`)}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-blue-400 hover:text-blue-300 group-hover:translate-x-0.5 transition-all py-1.5 px-3 rounded-lg bg-blue-950/40 hover:bg-blue-900/60 border border-blue-800/40"
                  aria-label={`Discuss ${item.title} on Telegram`}
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Discuss on Telegram</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </a>
              </div>

            </div>
          ))}
        </div>

        {/* Bottom Banner */}
        <div className="mt-12 text-center">
          <p className="text-sm text-slate-400">
            Kisi specific requirement par baat karni hai?{' '}
            <a
              href="https://t.me/Angad_ads"
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => trackTelegramClick('Services Section Bottom Link')}
              className="text-blue-400 font-medium hover:underline inline-flex items-center gap-1"
            >
              Direct Telegram par message bhejein
              <ArrowUpRight className="w-3.5 h-3.5" />
            </a>
          </p>
        </div>

      </div>
    </section>
  );
};
