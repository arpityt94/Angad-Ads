import React from 'react';
import { Send, ArrowUpRight, MessageCircle, Lightbulb, Cog, BarChart3 } from 'lucide-react';
import { trackTelegramClick } from '../utils/pixel';

export const HowItWorks: React.FC = () => {
  const steps = [
    {
      num: '01',
      stepLabel: 'STEP 01',
      title: 'Requirements Share Karein',
      desc: 'Telegram par apne business, services aur advertising goals ke baare mein batayein.',
      icon: <MessageCircle className="w-5 h-5 text-blue-400" />,
      tag: 'Initial Connect',
    },
    {
      num: '02',
      stepLabel: 'STEP 02',
      title: 'Strategy Discuss Karein',
      desc: 'Campaign approach, service fee aur advertising budget par discussion karein.',
      icon: <Lightbulb className="w-5 h-5 text-indigo-400" />,
      tag: 'Plan & Pricing',
    },
    {
      num: '03',
      stepLabel: 'STEP 03',
      title: 'Campaign Setup',
      desc: 'Agreed scope ke according campaign setup aur available tracking configuration ki jayegi.',
      icon: <Cog className="w-5 h-5 text-violet-400" />,
      tag: 'Technical Setup',
    },
    {
      num: '04',
      stepLabel: 'STEP 04',
      title: 'Performance Review',
      desc: 'Campaign data ko review karke possible improvements identify kiye jayenge.',
      icon: <BarChart3 className="w-5 h-5 text-emerald-400" />,
      tag: 'Continuous Review',
    },
  ];

  return (
    <section id="process" className="py-20 bg-transparent relative z-10 overflow-hidden cinematic-section-reveal">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-semibold tracking-wider uppercase text-blue-400 bg-blue-950/50 border border-blue-500/20 px-3 py-1 rounded-md inline-block mb-3">
            WORK PROCESS
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mb-4 text-balance">
            Kaam Kaise Start Hoga?
          </h2>
          <p className="text-base sm:text-lg text-slate-300 leading-relaxed text-balance">
            4 simple steps mein aapke business ke liye campaign setup aur strategic planning shuru ki ja sakti hai.
          </p>
        </div>

        {/* Desktop Horizontal Timeline / Mobile Vertical Timeline */}
        <div className="relative mb-14">
          
          {/* Desktop Connecting Line (hidden on mobile) */}
          <div className="hidden lg:block absolute top-16 left-[12%] right-[12%] h-0.5 bg-gradient-to-r from-blue-600/40 via-indigo-600/40 to-emerald-500/40 -z-0" />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 relative z-10">
            {steps.map((st, idx) => (
              <div
                key={st.num}
                className="rounded-2xl glass-card p-6 sm:p-7 glass-card-hover flex flex-col justify-between relative group"
              >
                <div>
                  {/* Step Header Badge & Icon */}
                  <div className="flex items-center justify-between mb-6">
                    <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-slate-900 to-slate-800 border border-slate-700/80 flex items-center justify-center shadow-md group-hover:border-blue-500/50 transition-colors">
                      {st.icon}
                    </div>
                    <span className="text-xs font-bold font-mono tracking-wider text-blue-400 px-2.5 py-1 rounded-md bg-blue-950/60 border border-blue-500/20">
                      {st.stepLabel}
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-white mb-2.5 group-hover:text-blue-300 transition-colors">
                    {st.title}
                  </h3>

                  <p className="text-sm text-slate-300/90 leading-relaxed">
                    {st.desc}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-800 text-[11px] font-mono text-slate-400 flex items-center justify-between">
                  <span>Step {idx + 1} of 4</span>
                  <span className="text-slate-300 font-sans">{st.tag}</span>
                </div>
              </div>
            ))}
          </div>

        </div>

        {/* Process CTA Button */}
        <div className="flex justify-center">
          <a
            href="https://t.me/Angad_ads"
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => trackTelegramClick('How It Works CTA')}
            className="inline-flex items-center gap-2.5 px-8 py-4 rounded-xl font-semibold text-sm sm:text-base text-white bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 shadow-xl shadow-blue-600/25 transition-all duration-200 active:scale-95 group"
          >
            <Send className="w-4 h-4 text-blue-200 group-hover:translate-x-0.5 transition-transform" />
            <span>Let's Discuss Your Project</span>
            <ArrowUpRight className="w-4 h-4 text-blue-200 opacity-80" />
          </a>
        </div>

      </div>
    </section>
  );
};
