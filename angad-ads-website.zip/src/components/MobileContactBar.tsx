import React, { useState } from 'react';
import { Send, Phone, X, ChevronUp, CheckCircle2 } from 'lucide-react';
import { trackTelegramClick, trackPhoneCall } from '../utils/pixel';

interface MobileContactBarProps {
  hidden?: boolean;
  onOpenCallModal?: () => void;
}

export const MobileContactBar: React.FC<MobileContactBarProps> = ({ hidden = false }) => {
  const [showCallMenu, setShowCallMenu] = useState(false);

  if (hidden) return null;

  return (
    <>
      {/* Mobile Popover Menu for Calling Numbers */}
      {showCallMenu && (
        <div
          className="md:hidden fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-end justify-center p-3"
          onClick={() => setShowCallMenu(false)}
        >
          <div
            className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-3xl p-5 shadow-2xl mb-16 animate-fadeIn"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-emerald-400" />
                <span>Select Number To Call</span>
              </span>
              <button
                type="button"
                onClick={() => setShowCallMenu(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
                aria-label="Close call menu"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2.5 mb-2">
              <a
                href="tel:+917888870589"
                onClick={() => {
                  trackPhoneCall('+91 7888870589', 'Primary', 'Mobile Popover L1');
                  setShowCallMenu(false);
                }}
                className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-950 border border-emerald-500/40 text-left active:scale-[0.98]"
              >
                <div>
                  <div className="text-[10px] uppercase font-semibold text-emerald-400 flex items-center gap-1">
                    <span>Primary Line</span>
                    <CheckCircle2 className="w-3 h-3" />
                  </div>
                  <div className="text-base font-bold text-white font-mono">
                    +91 7888870589
                  </div>
                </div>
                <div className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-bold">
                  Call Now
                </div>
              </a>

              <a
                href="tel:+918847415750"
                onClick={() => {
                  trackPhoneCall('+91 8847415750', 'Secondary', 'Mobile Popover L2');
                  setShowCallMenu(false);
                }}
                className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-950 border border-blue-500/40 text-left active:scale-[0.98]"
              >
                <div>
                  <div className="text-[10px] uppercase font-semibold text-blue-400">
                    Secondary Line
                  </div>
                  <div className="text-base font-bold text-white font-mono">
                    +91 8847415750
                  </div>
                </div>
                <div className="px-3 py-1.5 rounded-lg bg-blue-600 text-white text-xs font-bold">
                  Call Now
                </div>
              </a>
            </div>
          </div>
        </div>
      )}

      {/* Mobile Fixed Contact Bar (< md breakpoint) */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#030712]/95 backdrop-blur-lg border-t border-slate-800/90 px-4 py-3 safe-pb shadow-2xl">
        <div className="grid grid-cols-2 gap-3 max-w-md mx-auto">
          
          {/* Button 1: Telegram */}
          <a
            href="https://t.me/Angad_ads"
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => trackTelegramClick('Mobile Sticky Bar Telegram')}
            className="flex items-center justify-center gap-2 py-3 px-3 rounded-xl font-bold text-sm text-white bg-gradient-to-r from-blue-600 to-indigo-600 active:scale-95 transition-transform shadow-lg shadow-blue-600/30"
            aria-label="Open Telegram to contact Angad Ads"
          >
            <Send className="w-4 h-4 shrink-0" />
            <span className="truncate">Telegram</span>
          </a>

          {/* Button 2: Call Now (Opens Selection Menu) */}
          <button
            type="button"
            onClick={() => setShowCallMenu(!showCallMenu)}
            className="flex items-center justify-center gap-2 py-3 px-3 rounded-xl font-bold text-sm text-slate-100 bg-slate-900 border border-slate-700/80 active:scale-95 transition-transform hover:border-emerald-500/50"
            aria-label="Call Angad Ads"
          >
            <Phone className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="truncate">Call Now</span>
            <ChevronUp className="w-3.5 h-3.5 text-slate-400" />
          </button>

        </div>
      </div>

      {/* Desktop Floating Telegram Button (>= md breakpoint) */}
      <div className="hidden md:block fixed bottom-6 right-6 z-40">
        <a
          href="https://t.me/Angad_ads"
          target="_blank"
          rel="noopener noreferrer"
          onClick={() => trackTelegramClick('Desktop Floating Telegram Button')}
          className="group flex items-center gap-3 px-4 py-3 rounded-full bg-gradient-to-r from-blue-600 via-indigo-600 to-violet-600 text-white font-semibold text-sm shadow-2xl shadow-blue-600/40 hover:shadow-blue-500/60 hover:scale-105 active:scale-95 transition-all duration-200 border border-white/10"
          aria-label="Contact Angad Ads on Telegram"
        >
          <div className="w-7 h-7 rounded-full bg-white/20 flex items-center justify-center">
            <Send className="w-4 h-4 text-white group-hover:translate-x-0.5 transition-transform" />
          </div>
          <span className="pr-1">Chat on Telegram</span>
        </a>
      </div>
    </>
  );
};
