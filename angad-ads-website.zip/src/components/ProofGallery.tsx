import React, { useState } from 'react';
import { PAYMENT_PROOFS, CLIENT_REVIEWS, ProofItem } from '../data/proofs';
import { Shield, Lock, Eye, ChevronRight, ChevronLeft, X, Star, CheckCircle, Send, Phone } from 'lucide-react';
import { trackTelegramClick, trackPhoneCall } from '../utils/pixel';

interface ProofGalleryProps {
  onLightboxChange?: (isOpen: boolean) => void;
}

export const ProofGallery: React.FC<ProofGalleryProps> = ({ onLightboxChange }) => {
  const [activeTab, setActiveTab] = useState<'all' | 'payments' | 'reviews'>('all');
  const [selectedProofIndex, setSelectedProofIndex] = useState<number | null>(null);
  const [imageErrorMap, setImageErrorMap] = useState<Record<string, boolean>>({});

  const handleOpenLightbox = (index: number) => {
    setSelectedProofIndex(index);
    onLightboxChange?.(true);
  };

  const handleCloseLightbox = () => {
    setSelectedProofIndex(null);
    onLightboxChange?.(false);
  };

  const handlePrev = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (selectedProofIndex !== null) {
      setSelectedProofIndex((selectedProofIndex - 1 + PAYMENT_PROOFS.length) % PAYMENT_PROOFS.length);
    }
  };

  const handleNext = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (selectedProofIndex !== null) {
      setSelectedProofIndex((selectedProofIndex + 1) % PAYMENT_PROOFS.length);
    }
  };

  // Keyboard navigation
  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (selectedProofIndex === null) return;
      if (e.key === 'Escape') handleCloseLightbox();
      if (e.key === 'ArrowLeft') setSelectedProofIndex((prev) => (prev !== null ? (prev - 1 + PAYMENT_PROOFS.length) % PAYMENT_PROOFS.length : null));
      if (e.key === 'ArrowRight') setSelectedProofIndex((prev) => (prev !== null ? (prev + 1) % PAYMENT_PROOFS.length : null));
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedProofIndex]);

  const activeProof = selectedProofIndex !== null ? PAYMENT_PROOFS[selectedProofIndex] : null;

  return (
    <section id="proof" className="py-20 bg-[#040815]/60 relative z-10 border-b border-slate-800/70 cinematic-section-reveal">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="text-xs font-semibold tracking-wider uppercase text-emerald-400 bg-emerald-950/50 border border-emerald-500/20 px-3 py-1 rounded-md inline-block mb-3">
            VERIFIED PROOFS &amp; REVIEWS
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mb-4 text-balance">
            Client Feedback &amp; Payment Proof
          </h2>
          <p className="text-base sm:text-lg text-slate-300 leading-relaxed text-balance">
            Genuine feedback aur payment confirmations dekhein, jo permission ke saath share kiye gaye hain.
          </p>
        </div>

        {/* Security & Ethics Transparency Banner */}
        <div className="mb-10 rounded-2xl bg-slate-900/90 border border-slate-800 p-4 sm:p-5 text-xs sm:text-sm text-slate-300">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-lg bg-emerald-950/70 border border-emerald-500/30 text-emerald-400 shrink-0 mt-0.5">
                <Shield className="w-4 h-4" />
              </div>
              <div className="space-y-1">
                <p className="font-semibold text-white flex items-center gap-2">
                  <span>Privacy &amp; Compliance Protected</span>
                  <span className="text-[11px] font-normal text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/40">Verified</span>
                </p>
                <p className="text-slate-400 text-xs leading-relaxed">
                  Bank account numbers, UPI IDs aur sensitive transaction reference codes ko client privacy ke liye redact rakha gaya hai. Payment receive hona advertising results ya client profit ka guarantee nahi hai.
                </p>
              </div>
            </div>
          </div>

        </div>

        {/* Filter Tabs */}
        <div className="flex items-center justify-center gap-2 mb-10">
          <div className="p-1 rounded-xl bg-slate-900 border border-slate-800 flex items-center gap-1">
            <button
              type="button"
              onClick={() => setActiveTab('all')}
              className={`px-4 py-2 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'all'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              All Highlights
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('payments')}
              className={`px-4 py-2 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'payments'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Payment Confirmations ({PAYMENT_PROOFS.length})
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('reviews')}
              className={`px-4 py-2 rounded-lg text-xs font-semibold transition-all ${
                activeTab === 'reviews'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Client Feedback ({CLIENT_REVIEWS.length})
            </button>
          </div>
        </div>

        {/* Client Reviews Section (shown if 'all' or 'reviews') */}
        {(activeTab === 'all' || activeTab === 'reviews') && (
          <div className="mb-14">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <span>Genuine Client Feedback</span>
                <span className="text-xs font-normal text-slate-400">· Recent Experiences</span>
              </h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
              {CLIENT_REVIEWS.map((rev) => (
                <div
                  key={rev.id}
                  className="rounded-2xl glass-card p-5 glass-card-hover flex flex-col justify-between"
                >
                  <div>
                    {/* Rating stars */}
                    <div className="flex items-center gap-1 mb-3 text-amber-400">
                      {[...Array(rev.rating)].map((_, i) => (
                        <Star key={i} className="w-3.5 h-3.5 fill-amber-400" />
                      ))}
                    </div>

                    <p className="text-xs sm:text-sm text-slate-200 leading-relaxed italic mb-4">
                      "{rev.quote}"
                    </p>
                  </div>

                  <div className="pt-3 border-t border-slate-800/80">
                    <div className="font-semibold text-white text-xs">{rev.clientName}</div>
                    <div className="text-[11px] text-slate-400">
                      {rev.businessType} · {rev.location}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Payment Confirmation Screenshots Grid (shown if 'all' or 'payments') */}
        {(activeTab === 'all' || activeTab === 'payments') && (
          <div>
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <span>Payment Receipts Gallery</span>
                <span className="text-xs font-normal text-slate-400">· Tap any receipt to view full size</span>
              </h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
              {PAYMENT_PROOFS.map((proof, idx) => (
                <div
                  key={proof.id}
                  onClick={() => handleOpenLightbox(idx)}
                  className="group rounded-2xl bg-slate-900/90 border border-slate-800/90 hover:border-blue-500/50 overflow-hidden cursor-pointer transition-all duration-200 hover:-translate-y-1 hover:shadow-xl hover:shadow-blue-900/20 flex flex-col"
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      handleOpenLightbox(idx);
                    }
                  }}
                  aria-label={`View payment proof for ${proof.clientName}`}
                >
                  {/* Card Header: Exact Client Name Matching Screenshot + Amount */}
                  <div className="px-4 py-3 bg-slate-950/90 border-b border-slate-800 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 shrink-0 shadow-xs shadow-emerald-400/50" />
                      <span className="font-bold text-white text-sm sm:text-base truncate tracking-tight">
                        {proof.clientName}
                      </span>
                    </div>
                    <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-950/80 border border-emerald-500/30 px-2 py-0.5 rounded shrink-0">
                      {proof.amount}
                    </span>
                  </div>

                  {/* Image Container with Styled Fallback */}
                  <div className="relative aspect-[16/7] sm:aspect-[16/8] bg-slate-950 overflow-hidden flex items-center justify-center p-2">
                    {!imageErrorMap[proof.id] ? (
                      <img
                        src={proof.image}
                        alt={`Payment confirmation for ${proof.clientName}`}
                        loading="lazy"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-contain rounded-lg transition-transform duration-300 group-hover:scale-105"
                        onError={() => {
                          setImageErrorMap((prev) => ({ ...prev, [proof.id]: true }));
                        }}
                      />
                    ) : (
                      <div className="w-full h-full rounded-lg bg-slate-900 border border-slate-800 flex flex-col items-center justify-center p-3 text-center">
                        <CheckCircle className="w-6 h-6 text-emerald-400 mb-1" />
                        <span className="text-xs font-semibold text-white">{proof.clientName}</span>
                        <span className="text-[11px] text-emerald-400 font-mono">{proof.amount}</span>
                        <span className="text-[10px] text-slate-500 mt-1">Screenshot Verified</span>
                      </div>
                    )}

                    {/* Hover Inspect Overlay */}
                    <div className="absolute inset-0 bg-blue-950/40 opacity-0 group-hover:opacity-100 backdrop-blur-[2px] transition-opacity duration-200 flex items-center justify-center gap-1.5 text-white text-xs font-semibold">
                      <Eye className="w-4 h-4" />
                      <span>Click to Inspect</span>
                    </div>

                    {/* Redaction Shield Badge */}
                    <div className="absolute top-2 right-2 bg-black/70 backdrop-blur-md rounded-md p-1 text-slate-400 border border-white/10" title="Sensitive UPI & Account Details Redacted">
                      <Lock className="w-3 h-3 text-emerald-400" />
                    </div>
                  </div>

                  {/* Receipt Card Details Below Image: Exact Client Name matching screenshot & header */}
                  <div className="p-3.5 flex-1 flex flex-col justify-between bg-slate-900/60 border-t border-slate-800/60">
                    <div>
                      <div className="flex items-center justify-between gap-1 mb-1.5">
                        <div className="flex items-center gap-1.5 min-w-0">
                          <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                          <span className="font-bold text-white text-xs truncate">
                            {proof.clientName}
                          </span>
                        </div>
                        <span className="text-[11px] text-blue-400 font-semibold shrink-0">
                          {proof.service}
                        </span>
                      </div>

                      <p className="text-xs text-slate-400 leading-snug line-clamp-2">
                        {proof.caption}
                      </p>
                    </div>

                    <div className="mt-2.5 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500">
                      <span className="font-medium text-slate-400 font-mono">{proof.date}</span>
                      <span className="text-slate-400 group-hover:text-blue-400 transition-colors flex items-center gap-0.5">
                        Details <ChevronRight className="w-3 h-3" />
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Proof Gallery Bottom CTA Banner with Meta Pixel Tracking */}
        <div className="mt-14 rounded-3xl bg-gradient-to-r from-blue-950/70 via-slate-900 to-indigo-950/70 border border-blue-500/30 p-6 sm:p-8 text-center max-w-4xl mx-auto shadow-2xl">
          <span className="text-xs font-semibold tracking-wider uppercase text-blue-400 bg-blue-900/40 border border-blue-500/30 px-3 py-1 rounded-full inline-block mb-3">
            START YOUR CAMPAIGN OR TRAINING
          </span>
          <h3 className="text-2xl sm:text-3xl font-extrabold text-white mb-3">
            Aap Bhi Apne Business Ke Liye Ads Setup Karwayein Ya Seekhein
          </h3>
          <p className="text-sm text-slate-300 max-w-2xl mx-auto mb-6">
            Humse directly Telegram ya phone call par contact karein. Apni requirement aur budget share karein, aur immediate customized solution discuss karein.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4">
            <a
              href="https://t.me/Angad_ads"
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => trackTelegramClick('Proof Gallery Bottom CTA')}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-sm shadow-lg shadow-blue-600/30 active:scale-95 transition-all"
            >
              <Send className="w-4 h-4" />
              <span>Telegram Par Baat Karein</span>
            </a>

            <a
              href="tel:+917888870589"
              onClick={() => trackPhoneCall('+91 7888870589', 'Primary', 'Proof Gallery Bottom CTA')}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 hover:border-emerald-500/50 text-white font-bold text-sm active:scale-95 transition-all"
            >
              <Phone className="w-4 h-4 text-emerald-400" />
              <span>Direct Call Karein — 7888870589</span>
            </a>
          </div>
        </div>

      </div>

      {/* Lightbox Modal */}
      {activeProof && (
        <div
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 sm:p-6"
          onClick={handleCloseLightbox}
          role="dialog"
          aria-modal="true"
          aria-label="Payment Proof Lightbox"
        >
          <div
            className="relative max-w-3xl w-full bg-slate-900 border border-slate-700 rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-800 bg-slate-950/80">
              <div className="flex items-center gap-3">
                <div className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
                <div>
                  <h4 className="font-bold text-white text-sm sm:text-base">
                    {activeProof.clientName}
                  </h4>
                  <div className="text-[11px] text-slate-400">
                    {activeProof.service} · {activeProof.date}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-950 px-2.5 py-1 rounded border border-emerald-500/30">
                  {activeProof.amount}
                </span>
                <button
                  type="button"
                  onClick={handleCloseLightbox}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                  aria-label="Close Lightbox"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Modal Image Area */}
            <div className="relative flex-1 bg-black/90 flex items-center justify-center p-4 min-h-[260px] max-h-[60vh] overflow-auto">
              {!imageErrorMap[activeProof.id] ? (
                <img
                  src={activeProof.image}
                  alt={`Payment proof for ${activeProof.clientName}`}
                  className="max-h-full max-w-full object-contain rounded-lg"
                />
              ) : (
                <div className="p-8 text-center text-slate-400">
                  <CheckCircle className="w-12 h-12 text-emerald-400 mx-auto mb-2" />
                  <p className="text-sm font-semibold text-white">{activeProof.clientName}</p>
                  <p className="text-xs mt-1 font-mono text-emerald-400">{activeProof.amount}</p>
                  <p className="text-xs text-slate-500 mt-2">Genuine Client Receipt Recorded</p>
                </div>
              )}

              {/* Prev / Next Floating Arrows */}
              <button
                type="button"
                onClick={handlePrev}
                className="absolute left-3 top-1/2 -translate-y-1/2 p-2.5 rounded-full bg-slate-900/80 hover:bg-slate-800 text-white border border-slate-700/80 shadow-lg transition-transform active:scale-95"
                aria-label="Previous Receipt"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                type="button"
                onClick={handleNext}
                className="absolute right-3 top-1/2 -translate-y-1/2 p-2.5 rounded-full bg-slate-900/80 hover:bg-slate-800 text-white border border-slate-700/80 shadow-lg transition-transform active:scale-95"
                aria-label="Next Receipt"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-slate-950 border-t border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs text-slate-300">
              <div className="space-y-1">
                <p className="text-slate-200">{activeProof.caption}</p>
                <p className="text-[11px] text-slate-500 flex items-center gap-1.5">
                  <Lock className="w-3 h-3 text-emerald-400" />
                  <span>Personal banking details and sensitive references redacted as per privacy guidelines.</span>
                </p>
              </div>

              <div className="text-[11px] text-slate-400 font-mono shrink-0">
                {(selectedProofIndex ?? 0) + 1} of {PAYMENT_PROOFS.length}
              </div>
            </div>

          </div>
        </div>
      )}

    </section>
  );
};
