import React, { useState } from 'react';
import { ChevronDown, HelpCircle, Send, Phone } from 'lucide-react';
import { trackTelegramClick, trackPhoneCall } from '../utils/pixel';

interface FAQItem {
  id: string;
  question: string;
  answer: string;
}

export const FAQ: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0); // First item open by default

  const faqs: FAQItem[] = [
    {
      id: 'faq-1',
      question: 'Meta Ads setup ke liye kya chahiye?',
      answer: 'Aapko apne business details, campaign objective, target audience aur approximate advertising budget share karna hoga.',
    },
    {
      id: 'faq-2',
      question: 'Kya aap different types ke businesses ke liye kaam karte ho?',
      answer: 'Different legitimate business categories discuss ki ja sakti hain. Final campaign service aur platform advertising policies par depend karegi.',
    },
    {
      id: 'faq-3',
      question: 'Kya advertising budget service fee mein included hai?',
      answer: 'Service fee aur advertising spend ko separately discuss kiya jayega, taaki aapko complete clarity rahe.',
    },
    {
      id: 'faq-4',
      question: 'Kya guaranteed leads milengi?',
      answer: 'Advertising results budget, audience, offer, creative aur competition jaise factors par depend karte hain. Isliye fixed leads ya sales ki guarantee nahi di ja sakti.',
    },
    {
      id: 'faq-5',
      question: 'Kya Meta Ads 100% approve ho jayenge?',
      answer: 'Campaign ko applicable policies ke according prepare kiya jayega, lekin final approval advertising platform ke decision par depend karta hai.',
    },
    {
      id: 'faq-6',
      question: 'Contact kaise karein?',
      answer: 'Aap Telegram par message kar sakte hain ya direct call karke apni requirements discuss kar sakte hain.',
    },
  ];

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section id="faq" className="py-20 bg-[#040815]/55 relative z-10 border-t border-slate-800/70 cinematic-section-reveal">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="text-xs font-semibold tracking-wider uppercase text-blue-400 bg-blue-950/50 border border-blue-500/20 px-3 py-1 rounded-md inline-block mb-3">
            QUESTIONS &amp; ANSWERS
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mb-4 text-balance">
            Frequently Asked Questions
          </h2>
          <p className="text-base text-slate-300 leading-relaxed text-balance">
            Meta Ads setup aur hamare working process ke baare mein aksar pooche jane wale common sawaal.
          </p>
        </div>

        {/* Accordion List */}
        <div className="space-y-3.5 mb-12">
          {faqs.map((faq, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div
                key={faq.id}
                className="rounded-2xl glass-card border border-slate-800/80 transition-all overflow-hidden"
              >
                <button
                  type="button"
                  onClick={() => toggleFAQ(idx)}
                  className="w-full text-left px-5 sm:px-6 py-4.5 flex items-center justify-between gap-4 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded-2xl"
                  aria-expanded={isOpen}
                >
                  <span className="text-base sm:text-lg font-bold text-white flex items-center gap-3">
                    <span className="text-xs font-mono font-semibold text-blue-400 shrink-0">
                      Q{idx + 1}.
                    </span>
                    <span>{faq.question}</span>
                  </span>
                  <div
                    className={`p-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 shrink-0 transition-transform duration-200 ${
                      isOpen ? 'rotate-180 text-blue-400 bg-blue-950/50 border-blue-500/30' : ''
                    }`}
                  >
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                {isOpen && (
                  <div className="px-5 sm:px-6 pb-5 pt-1 text-sm text-slate-300/95 leading-relaxed border-t border-slate-800/40">
                    <p className="bg-slate-900/60 p-3.5 rounded-xl border border-slate-800/60">
                      {faq.answer}
                    </p>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Extra Question Assistance Box */}
        <div className="rounded-2xl bg-gradient-to-r from-blue-950/40 via-indigo-950/30 to-slate-900/40 border border-blue-800/30 p-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400 shrink-0">
              <HelpCircle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Koi doosra sawaal hai?</h3>
              <p className="text-xs text-slate-400">Telegram par ya direct call par discuss karein.</p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            <a
              href="https://t.me/Angad_ads"
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => trackTelegramClick('FAQ Bottom Help Box')}
              className="px-4 py-2 text-xs font-semibold rounded-lg bg-blue-600 hover:bg-blue-500 text-white flex items-center gap-1.5 shadow-md shadow-blue-600/20"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Telegram</span>
            </a>
            <a
              href="tel:+917888870589"
              onClick={() => trackPhoneCall('+91 7888870589', 'Primary', 'FAQ Bottom Help Box')}
              className="px-4 py-2 text-xs font-semibold rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 flex items-center gap-1.5"
            >
              <Phone className="w-3.5 h-3.5 text-emerald-400" />
              <span>Call Karein</span>
            </a>
          </div>
        </div>

      </div>
    </section>
  );
};
