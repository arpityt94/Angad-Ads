import React, { useState, useEffect } from 'react';
import { Send, Phone, Menu, X, ArrowUpRight } from 'lucide-react';
import { trackTelegramClick, trackPhoneCall } from '../utils/pixel';

export const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Home', href: '#home' },
    { label: 'Services', href: '#services' },
    { label: 'Process', href: '#process' },
    { label: 'Proof', href: '#proof' },
    { label: 'FAQ', href: '#faq' },
  ];

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          isScrolled
            ? 'bg-[#030712]/90 backdrop-blur-md border-b border-slate-800/80 shadow-lg shadow-black/40 py-3.5'
            : 'bg-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between gap-8">
            {/* Zone 1: Brand Wordmark */}
            <a
              href="#home"
              className="flex items-center gap-2 group whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded-lg p-1"
            >
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-violet-500 flex items-center justify-center shadow-lg shadow-blue-500/20 group-hover:scale-105 transition-transform duration-200">
                <span className="font-extrabold text-white text-base tracking-wider font-mono">A</span>
              </div>
              <div className="flex flex-col">
                <span className="text-xl font-extrabold tracking-tight text-white group-hover:text-blue-400 transition-colors">
                  ANGAD<span className="text-blue-500">ADS</span>
                </span>
              </div>
            </a>

            {/* Zone 2: Navigation Links (Desktop) */}
            <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-300">
              {navLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  className="hover:text-blue-400 transition-colors whitespace-nowrap shrink-0 py-1 border-b border-transparent hover:border-blue-500/40"
                >
                  {link.label}
                </a>
              ))}
            </nav>

            {/* Zone 3: 1 Primary Action (Desktop & Mobile Menu Trigger) */}
            <div className="flex items-center gap-3 shrink-0">
              <a
                href="https://t.me/Angad_ads"
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => trackTelegramClick('Navbar Top Bar Button')}
                className="hidden sm:inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 rounded-lg shadow-md shadow-blue-600/25 hover:shadow-blue-500/40 transition-all duration-200 active:scale-95 whitespace-nowrap shrink-0"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Let's Talk</span>
                <ArrowUpRight className="w-3.5 h-3.5 opacity-70" />
              </a>

              {/* Mobile Hamburger Button */}
              <button
                type="button"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                aria-label={mobileMenuOpen ? 'Close Menu' : 'Open Menu'}
                aria-expanded={mobileMenuOpen}
                className="md:hidden p-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800/80 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-30 md:hidden bg-black/75 backdrop-blur-md pt-20 px-6 pb-8 flex flex-col justify-between animate-fadeIn">
          <div className="flex flex-col space-y-4 pt-4">
            <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider px-2">Navigation</div>
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="px-4 py-3 rounded-xl text-lg font-medium text-slate-200 hover:text-white hover:bg-slate-800/60 transition-colors flex items-center justify-between"
              >
                <span>{link.label}</span>
                <ArrowUpRight className="w-4 h-4 text-slate-500" />
              </a>
            ))}
          </div>

          <div className="space-y-2.5 pt-6 border-t border-slate-800">
            <a
              href="https://t.me/Angad_ads"
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => {
                trackTelegramClick('Navbar Mobile Drawer Telegram');
                setMobileMenuOpen(false);
              }}
              className="w-full py-3 px-4 rounded-xl font-semibold text-sm bg-gradient-to-r from-blue-600 to-indigo-600 text-white flex items-center justify-center gap-2 shadow-lg shadow-blue-600/30"
            >
              <Send className="w-4 h-4" />
              <span>Telegram Par Baat Karein</span>
            </a>

            <div className="grid grid-cols-2 gap-2 pt-1">
              <a
                href="tel:+917888870589"
                onClick={() => {
                  trackPhoneCall('+91 7888870589', 'Primary', 'Navbar Mobile Drawer');
                  setMobileMenuOpen(false);
                }}
                className="py-3 px-3 rounded-xl font-semibold text-xs bg-slate-900 border border-emerald-500/40 text-slate-200 hover:text-white flex flex-col items-center justify-center text-center gap-1"
              >
                <div className="flex items-center gap-1 text-emerald-400 font-bold">
                  <Phone className="w-3.5 h-3.5" />
                  <span>Call L1</span>
                </div>
                <span className="font-mono text-[11px] text-slate-300">7888870589</span>
              </a>

              <a
                href="tel:+918847415750"
                onClick={() => {
                  trackPhoneCall('+91 8847415750', 'Secondary', 'Navbar Mobile Drawer');
                  setMobileMenuOpen(false);
                }}
                className="py-3 px-3 rounded-xl font-semibold text-xs bg-slate-900 border border-blue-500/40 text-slate-200 hover:text-white flex flex-col items-center justify-center text-center gap-1"
              >
                <div className="flex items-center gap-1 text-blue-400 font-bold">
                  <Phone className="w-3.5 h-3.5" />
                  <span>Call L2</span>
                </div>
                <span className="font-mono text-[11px] text-slate-300">8847415750</span>
              </a>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
