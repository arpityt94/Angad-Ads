import React from 'react';
import { Store, GraduationCap, ShoppingBag, Building2, Briefcase, Users2, Rocket, Globe, ShieldAlert } from 'lucide-react';

export const Industries: React.FC = () => {
  const industries = [
    {
      title: 'Local Businesses',
      examples: 'Clinics, salons, restaurants, auto workshops, local repair & retail shops.',
      icon: <Store className="w-6 h-6 text-blue-400" />,
    },
    {
      title: 'Education & Training',
      examples: 'Coaching centers, skill institutes, spoken English, computer academies.',
      icon: <GraduationCap className="w-6 h-6 text-indigo-400" />,
    },
    {
      title: 'E-commerce',
      examples: 'D2C apparel, footwear, accessories, niche physical consumer goods.',
      icon: <ShoppingBag className="w-6 h-6 text-cyan-400" />,
    },
    {
      title: 'Real Estate',
      examples: 'Property consultants, plots, residential apartments, rental advisors.',
      icon: <Building2 className="w-6 h-6 text-violet-400" />,
    },
    {
      title: 'Professional Services',
      examples: 'Financial advisors, chartered accountants, legal firms, interior designers.',
      icon: <Briefcase className="w-6 h-6 text-emerald-400" />,
    },
    {
      title: 'Agencies & Freelancers',
      examples: 'Video editors, graphic designers, software builders seeking client leads.',
      icon: <Users2 className="w-6 h-6 text-amber-400" />,
    },
    {
      title: 'Startups',
      examples: 'Early stage ventures, consumer mobile apps, SaaS tools & tech services.',
      icon: <Rocket className="w-6 h-6 text-rose-400" />,
    },
    {
      title: 'Eligible Online Services',
      examples: 'Consultants, course creators, digital agencies, legitimate online providers.',
      icon: <Globe className="w-6 h-6 text-blue-400" />,
    },
  ];

  return (
    <section className="py-20 bg-transparent relative z-10 cinematic-section-reveal">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-semibold tracking-wider uppercase text-blue-400 bg-blue-950/50 border border-blue-500/20 px-3 py-1 rounded-md inline-block mb-3">
            TARGET AUDIENCES
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mb-4 text-balance">
            Different Businesses Ke Liye Ads Support
          </h2>
          <p className="text-base sm:text-lg text-slate-300 leading-relaxed text-balance">
            Chahe aap kisi local area mein operate karte hon ya all-India audience ko serve karte hon, hum aapki category ke according strategy plan kar sakte hain.
          </p>
        </div>

        {/* 8 Industries Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-10">
          {industries.map((ind) => (
            <div
              key={ind.title}
              className="p-5 rounded-2xl glass-card glass-card-hover flex flex-col justify-between"
            >
              <div>
                <div className="w-11 h-11 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center mb-4">
                  {ind.icon}
                </div>
                <h3 className="text-base font-bold text-white mb-2">{ind.title}</h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {ind.examples}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800/80 text-[11px] text-blue-400 font-medium">
                Custom Ad Strategy Available
              </div>
            </div>
          ))}
        </div>

        {/* Supporting Compliance Text */}
        <div className="max-w-2xl mx-auto text-center p-4 rounded-xl bg-slate-900/60 border border-slate-800 text-xs text-slate-400 flex items-center justify-center gap-2">
          <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
          <span>
            Apne business ki requirements share karein. Campaign eligibility aur setup applicable advertising policies aur service requirements par depend karega.
          </span>
        </div>

      </div>
    </section>
  );
};
