import React from 'react';
import { Phone, X, CheckCircle2, ArrowRight } from 'lucide-react';
import { trackPhoneCall } from '../utils/pixel';

interface CallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CallModal: React.FC<CallModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-4"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label="Direct Calling Lines"
    >
      <div
        className="w-full max-w-sm bg-slate-900 border border-slate-700/80 rounded-3xl p-6 shadow-2xl relative animate-fadeIn"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-5">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-950/80 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <Phone className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base leading-tight">Direct Call Karein</h3>
              <p className="text-xs text-slate-400">Choose calling line</p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Number Options */}
        <div className="space-y-3 mb-5">
          {/* Number 1: Primary */}
          <a
            href="tel:+917888870589"
            className="group flex items-center justify-between p-3.5 rounded-2xl bg-slate-950/80 hover:bg-slate-800 border border-emerald-500/30 hover:border-emerald-500 transition-all active:scale-[0.98]"
            onClick={() => {
              trackPhoneCall('+91 7888870589', 'Primary', 'Call Modal L1');
              onClose();
            }}
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center font-bold text-xs shrink-0">
                L1
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-[11px] font-semibold text-emerald-400 uppercase tracking-wider">
                    Primary Line
                  </span>
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                </div>
                <div className="text-base font-bold text-white font-mono tracking-wide">
                  +91 7888870589
                </div>
              </div>
            </div>
            <div className="p-2 rounded-xl bg-emerald-500 text-slate-950 font-bold group-hover:translate-x-0.5 transition-transform">
              <ArrowRight className="w-4 h-4" />
            </div>
          </a>

          {/* Number 2: Secondary */}
          <a
            href="tel:+918847415750"
            className="group flex items-center justify-between p-3.5 rounded-2xl bg-slate-950/80 hover:bg-slate-800 border border-slate-700/80 hover:border-blue-500 transition-all active:scale-[0.98]"
            onClick={() => {
              trackPhoneCall('+91 8847415750', 'Secondary', 'Call Modal L2');
              onClose();
            }}
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center font-bold text-xs shrink-0">
                L2
              </div>
              <div>
                <span className="text-[11px] font-semibold text-blue-400 uppercase tracking-wider block">
                  Secondary Support Line
                </span>
                <div className="text-base font-bold text-white font-mono tracking-wide">
                  +91 8847415750
                </div>
              </div>
            </div>
            <div className="p-2 rounded-xl bg-slate-800 text-slate-200 group-hover:bg-blue-600 group-hover:text-white transition-colors">
              <ArrowRight className="w-4 h-4" />
            </div>
          </a>
        </div>

        {/* Footer info */}
        <p className="text-[11px] text-center text-slate-400 leading-relaxed">
          Dono numbers direct available hain. Setup ya training ke baare mein baat karne ke liye abhi call karein.
        </p>
      </div>
    </div>
  );
};
