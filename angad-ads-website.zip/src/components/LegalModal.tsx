import React, { useState } from 'react';
import { X, Shield, FileText, CheckCircle2 } from 'lucide-react';

interface LegalModalProps {
  initialTab?: 'privacy' | 'terms';
  onClose: () => void;
}

export const LegalModal: React.FC<LegalModalProps> = ({ initialTab = 'privacy', onClose }) => {
  const [tab, setTab] = useState<'privacy' | 'terms'>(initialTab);

  return (
    <div
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 sm:p-6"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label="Legal Documents Modal"
    >
      <div
        className="relative max-w-3xl w-full bg-slate-900 border border-slate-700/80 rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[88vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/80">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-blue-950 text-blue-400 border border-blue-500/30">
              {tab === 'privacy' ? <Shield className="w-4 h-4" /> : <FileText className="w-4 h-4" />}
            </div>
            <div>
              <h3 className="font-bold text-white text-base">
                {tab === 'privacy' ? 'Privacy Policy' : 'Terms of Service'}
              </h3>
              <p className="text-[11px] text-slate-400">ANGAD ADS Legal Documentation</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Tab switchers inside modal */}
            <div className="flex p-0.5 rounded-lg bg-slate-900 border border-slate-800 text-xs">
              <button
                type="button"
                onClick={() => setTab('privacy')}
                className={`px-3 py-1 rounded-md font-medium transition-colors ${
                  tab === 'privacy' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Privacy
              </button>
              <button
                type="button"
                onClick={() => setTab('terms')}
                className={`px-3 py-1 rounded-md font-medium transition-colors ${
                  tab === 'terms' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Terms
              </button>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors ml-2"
              aria-label="Close Legal Modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-sm text-slate-300 leading-relaxed">
          
          {tab === 'privacy' ? (
            <>
              <div>
                <span className="text-xs font-mono text-blue-400 uppercase tracking-wider block mb-1">Last Updated: October 2026</span>
                <h4 className="text-lg font-bold text-white mb-2">Privacy Policy &amp; Data Protection</h4>
                <p>
                  ANGAD ADS ("Hum", "Hamari service") aapki personal information aur business data ki privacy ka poora dhyan rakhti hai. Yeh policy batati hai ki hum client communication aur campaign execution ke dauran kya information collect karte hain aur use kaise protect karte hain.
                </p>
              </div>

              <div className="space-y-3">
                <h5 className="font-semibold text-white text-base">1. Information We Collect</h5>
                <p>
                  Jab aap humse Telegram ya Phone call ke zariye sampark karte hain, tab hum aapse sirf essential business details collect karte hain:
                </p>
                <ul className="list-disc pl-5 space-y-1 text-slate-300/90 text-xs sm:text-sm">
                  <li>Business ka naam, product/service details aur target audience location.</li>
                  <li>Contact details (Phone number, WhatsApp/Telegram username).</li>
                  <li>Advertising preferences aur planned monthly/weekly campaign budget.</li>
                </ul>
              </div>

              <div className="space-y-3">
                <h5 className="font-semibold text-white text-base">2. Financial Data &amp; Redaction</h5>
                <p>
                  Hum kisi bhi client ka bank account password, credit/debit card numbers ya private UPI PIN store nahi karte. Payment confirmations sirf service acknowledgment ke liye use kiye jaate hain, aur screenshots publish karte waqt sensitive account numbers aur reference IDs ko redact kar diya jata hai.
                </p>
              </div>

              <div className="space-y-3">
                <h5 className="font-semibold text-white text-base">3. Third-Party Sharing</h5>
                <p>
                  Aapka private data kisi bhi third-party marketing agency ya data broker ko becha ya rent nahi kiya jata. Information sirf campaign setup aur advertising account configuration ke liye hi use ki jaati hai.
                </p>
              </div>

              <div className="space-y-3">
                <h5 className="font-semibold text-white text-base">4. Contact For Privacy Queries</h5>
                <p>
                  Agar aapko privacy policy ya data treatment ke regarding koi sawal ho, toh aap direct Telegram: <a href="https://t.me/Angad_ads" className="text-blue-400 hover:underline">@Angad_ads</a> ya phone <strong className="text-white">+91 7888870589</strong> par contact kar sakte hain.
                </p>
              </div>
            </>
          ) : (
            <>
              <div>
                <span className="text-xs font-mono text-blue-400 uppercase tracking-wider block mb-1">Last Updated: October 2026</span>
                <h4 className="text-lg font-bold text-white mb-2">Terms of Service &amp; Working Agreement</h4>
                <p>
                  ANGAD ADS ki services lene se pehle kripya in sharto ko dhyan se padh lein. Yeh terms client aur service provider ke beech clear transparency establish karne ke liye banaye gaye hain.
                </p>
              </div>

              <div className="space-y-3">
                <h5 className="font-semibold text-white text-base">1. Scope of Service</h5>
                <p>
                  ANGAD ADS business owners ke liye Facebook aur Instagram advertising campaigns ka professional setup, audience targeting configuration aur optimization support provide karta hai.
                </p>
              </div>

              <div className="space-y-3">
                <h5 className="font-semibold text-white text-base">2. Service Fee vs Ad Spend Separation</h5>
                <p>
                  Humari <strong className="text-white">Service Management Fee</strong> aur Meta Platforms ko diye jane wale <strong className="text-white">Direct Ad Spend (Budget)</strong> dono alag-alag hain. Ad spend directly aapke Meta Ad Account se deduct hota hai ya mutually agreed payment structure ke through execute kiya jata hai.
                </p>
              </div>

              <div className="space-y-3">
                <h5 className="font-semibold text-white text-base">3. No Guaranteed Results or Fixed Sales Disclaimer</h5>
                <p>
                  Advertising results customer demand, product pricing, creative offer, landing page quality aur industry competition par depend karte hain. Isliye fixed inquiry count ya guaranteed revenue ka vaada nahi kiya ja sakta.
                </p>
              </div>

              <div className="space-y-3">
                <h5 className="font-semibold text-white text-base">4. Platform Advertising Policy Compliance</h5>
                <p>
                  Meta Platforms, Inc. ki apni community guidelines aur advertising policies hoti hain. Hum campaign ko policy-compliant banane ki poori koshish karte hain, lekin ad account approval ya final ad review Meta ke internal policies par nirbhar karta hai.
                </p>
              </div>

              <div className="space-y-3">
                <h5 className="font-semibold text-white text-base">5. Meta Platforms Independence Disclosure</h5>
                <p className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-400">
                  ANGAD ADS ek independent digital marketing aur advertising consulting service hai. Yeh website aur service Meta Platforms, Inc. se officially affiliated, associated, authorized ya endorsed nahi hai.
                </p>
              </div>
            </>
          )}

        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between">
          <div className="text-xs text-slate-500 flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>Document version 1.0 (Editable by Owner)</span>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold transition-colors"
          >
            Samajh Gaya (Close)
          </button>
        </div>

      </div>
    </div>
  );
};
