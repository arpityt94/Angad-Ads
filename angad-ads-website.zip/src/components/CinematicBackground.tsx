import React, { useEffect, useRef } from 'react';

interface Particle {
  x: number;
  y: number;
  radius: number;
  vx: number;
  vy: number;
  alpha: number;
  baseAlpha: number;
  phase: number;
  color: string;
}

interface LightningSegment {
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  thickness: number;
  alpha: number;
}

interface ActiveLightning {
  segments: LightningSegment[];
  originX: number;
  originY: number;
  startTime: number;
  duration: number;
  isDoubleFlash: boolean;
  isSubtle: boolean;
  maxIntensity: number;
  hue: 'blue' | 'violet';
}

/**
 * Ultra-Premium 5-Layer Cinematic Lightning & Atmospheric Background
 * - Zero React re-renders during animation
 * - GPU-friendly HTML5 Canvas + CSS atmospheric layers
 * - Respects prefers-reduced-motion & pauses when tab is inactive
 * - Optimized particle count and resolution on Android / mobile devices
 */
export const CinematicBackground: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const flashOverlayRef = useRef<HTMLDivElement | null>(null);
  const parallaxLayerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    if (mediaQuery.matches) {
      return;
    }

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) return;

    let animationFrameId: number;
    let width = window.innerWidth;
    let height = window.innerHeight;
    let isMobile = width < 768;

    // Detect low-power device (e.g., <= 4 cores on mobile)
    const cores = navigator.hardwareConcurrency || 4;
    const isLowPower = isMobile && cores <= 4;

    const setCanvasSize = () => {
      width = window.innerWidth;
      height = window.innerHeight;
      isMobile = width < 768;
      // Cap DPR at 1.5 on mobile for crisp yet ultra-fast rendering
      const dpr = Math.min(window.devicePixelRatio || 1, isMobile ? 1.25 : 1.75);
      canvas.width = width * dpr;
      canvas.height = height * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    setCanvasSize();

    // Layer 3: Drifting electric-blue & violet atmospheric particles
    const particleCount = isLowPower ? 16 : isMobile ? 24 : 46;
    const colors = ['#60a5fa', '#38bdf8', '#818cf8', '#a78bfa'];
    const particles: Particle[] = Array.from({ length: particleCount }, () => {
      const baseAlpha = 0.12 + Math.random() * 0.35;
      return {
        x: Math.random() * width,
        y: Math.random() * height,
        radius: 0.7 + Math.random() * (isMobile ? 1.3 : 1.8),
        vx: (Math.random() - 0.5) * 0.18,
        vy: -0.08 - Math.random() * 0.22, // slow upward drift
        alpha: baseAlpha,
        baseAlpha,
        phase: Math.random() * Math.PI * 2,
        color: colors[Math.floor(Math.random() * colors.length)],
      };
    });

    // Procedural branching lightning generator
    const createLightningBolt = (): ActiveLightning => {
      const isSubtle = Math.random() < 0.45; // 45% very subtle distant flash
      const isDoubleFlash = !isSubtle && Math.random() < 0.38; // Occasional double flash
      const duration = isDoubleFlash
        ? 240 + Math.random() * 70 // ~240-310ms for double flash
        : 110 + Math.random() * 140; // ~110-250ms for single flash

      const originX = width * (0.12 + Math.random() * 0.76);
      const originY = height * (0.02 + Math.random() * 0.22);
      const segments: LightningSegment[] = [];

      const generateBranch = (
        startX: number,
        startY: number,
        angle: number,
        length: number,
        thickness: number,
        branchAlpha: number,
        depth: number
      ) => {
        if (depth > 3 || thickness < 0.3) return;

        let currX = startX;
        let currY = startY;
        const steps = isMobile ? 10 : 14;
        const stepLength = length / steps;

        for (let i = 0; i < steps; i++) {
          const jitter = (Math.random() - 0.5) * 0.65;
          const currentAngle = angle + jitter;
          const nextX = currX + Math.cos(currentAngle) * stepLength;
          const nextY = currY + Math.sin(currentAngle) * stepLength;

          segments.push({
            x1: currX,
            y1: currY,
            x2: nextX,
            y2: nextY,
            thickness: thickness * (1 - (i / steps) * 0.45),
            alpha: branchAlpha * (1 - (i / steps) * 0.35),
          });

          // Spawn sub-branch occasionally
          if (depth < 2 && i > 2 && i < steps - 2 && Math.random() < 0.26) {
            const subAngle = currentAngle + (Math.random() > 0.5 ? 0.45 : -0.45);
            generateBranch(
              nextX,
              nextY,
              subAngle,
              length * 0.48,
              thickness * 0.55,
              branchAlpha * 0.65,
              depth + 1
            );
          }

          currX = nextX;
          currY = nextY;
        }
      };

      // Main bolt angle: traveling diagonally across distant clouds or downward
      const mainAngle = Math.PI / 2 + (Math.random() - 0.5) * 0.95;
      const mainLength = Math.min(width, height) * (isSubtle ? 0.32 : 0.52);
      const baseThickness = isSubtle ? 1.1 : 1.8;
      const maxIntensity = isSubtle ? 0.28 : isDoubleFlash ? 0.68 : 0.48;

      generateBranch(originX, originY, mainAngle, mainLength, baseThickness, 1, 0);

      // Sometimes add a secondary fork near origin
      if (!isSubtle && Math.random() < 0.6) {
        generateBranch(
          originX,
          originY,
          mainAngle + (Math.random() > 0.5 ? 0.5 : -0.5),
          mainLength * 0.6,
          baseThickness * 0.7,
          0.75,
          1
        );
      }

      return {
        segments,
        originX,
        originY,
        startTime: performance.now(),
        duration,
        isDoubleFlash,
        isSubtle,
        maxIntensity,
        hue: Math.random() < 0.72 ? 'blue' : 'violet',
      };
    };

    let activeLightning: ActiveLightning | null = null;
    // Schedule first subtle lightning after 2.8 seconds, then every 6–12 seconds
    let nextLightningTime = performance.now() + 2800 + Math.random() * 2200;

    const computeFlashEnvelope = (progress: number, isDouble: boolean): number => {
      if (progress < 0 || progress > 1) return 0;
      if (!isDouble) {
        // Fast attack (0 -> 0.2), smooth atmospheric decay (0.2 -> 1.0)
        if (progress < 0.2) return progress / 0.2;
        return Math.pow(1 - (progress - 0.2) / 0.8, 1.8);
      } else {
        // Double flash: pulse 1 (0 -> 0.35), brief dip (0.35 -> 0.5), brighter pulse 2 (0.5 -> 1.0)
        if (progress < 0.15) return (progress / 0.15) * 0.75;
        if (progress < 0.38) return 0.75 * (1 - (progress - 0.15) / 0.23) + 0.12;
        if (progress < 0.52) return 0.12 + ((progress - 0.38) / 0.14) * 0.88;
        return Math.pow(1 - (progress - 0.52) / 0.48, 2.0);
      }
    };

    const render = (now: number) => {
      if (document.hidden) {
        animationFrameId = requestAnimationFrame(render);
        return;
      }

      ctx.clearRect(0, 0, width, height);

      // 1. Update & draw drifting atmospheric particles
      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];
        p.x += p.vx;
        p.y += p.vy;
        p.phase += 0.015;

        if (p.y < -10) p.y = height + 10;
        if (p.x < -10) p.x = width + 10;
        if (p.x > width + 10) p.x = -10;

        const currentAlpha = p.baseAlpha * (0.65 + 0.35 * Math.sin(p.phase));
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.globalAlpha = currentAlpha;
        ctx.fill();
      }
      ctx.globalAlpha = 1;

      // 2. Trigger random lightning flash every 6–12 seconds
      if (!activeLightning && now >= nextLightningTime) {
        activeLightning = createLightningBolt();
        // Next interval strictly 6000ms to 12000ms
        nextLightningTime = now + 6000 + Math.random() * 6000;
      }

      // 3. Render active lightning bolt & distant cloud illumination
      if (activeLightning) {
        const elapsed = now - activeLightning.startTime;
        const progress = elapsed / activeLightning.duration;

        if (progress >= 1) {
          activeLightning = null;
          if (flashOverlayRef.current) {
            flashOverlayRef.current.style.opacity = '0';
          }
        } else {
          const envelope = computeFlashEnvelope(progress, activeLightning.isDoubleFlash);
          const intensity = envelope * activeLightning.maxIntensity;

          // Distant cloud radial glow around bolt origin
          const cloudRadius = Math.max(width, height) * (activeLightning.isSubtle ? 0.35 : 0.52);
          const grad = ctx.createRadialGradient(
            activeLightning.originX,
            activeLightning.originY,
            10,
            activeLightning.originX,
            activeLightning.originY,
            cloudRadius
          );

          if (activeLightning.hue === 'blue') {
            grad.addColorStop(0, `rgba(96, 165, 250, ${intensity * 0.22})`);
            grad.addColorStop(0.4, `rgba(37, 99, 235, ${intensity * 0.09})`);
            grad.addColorStop(1, 'rgba(3, 7, 18, 0)');
          } else {
            grad.addColorStop(0, `rgba(167, 139, 250, ${intensity * 0.2})`);
            grad.addColorStop(0.4, `rgba(109, 40, 217, ${intensity * 0.08})`);
            grad.addColorStop(1, 'rgba(3, 7, 18, 0)');
          }

          ctx.fillStyle = grad;
          ctx.fillRect(0, 0, width, height);

          // Draw branching segments
          ctx.save();
          ctx.lineCap = 'round';
          ctx.lineJoin = 'round';

          const glowColor =
            activeLightning.hue === 'blue'
              ? 'rgba(59, 130, 246, 0.85)'
              : 'rgba(139, 92, 246, 0.85)';
          const coreColor =
            activeLightning.hue === 'blue'
              ? 'rgba(219, 234, 254, 0.95)'
              : 'rgba(237, 233, 254, 0.95)';

          // Outer electric glow pass
          ctx.shadowColor = glowColor;
          ctx.shadowBlur = isMobile ? 8 : 14;

          for (let i = 0; i < activeLightning.segments.length; i++) {
            const seg = activeLightning.segments[i];
            const segAlpha = seg.alpha * intensity;
            if (segAlpha <= 0.01) continue;

            ctx.beginPath();
            ctx.moveTo(seg.x1, seg.y1);
            ctx.lineTo(seg.x2, seg.y2);
            ctx.strokeStyle = coreColor;
            ctx.lineWidth = seg.thickness;
            ctx.globalAlpha = segAlpha;
            ctx.stroke();
          }

          ctx.restore();

          // Subtle ambient screen glow during flash
          if (flashOverlayRef.current) {
            flashOverlayRef.current.style.opacity = String((intensity * 0.14).toFixed(3));
          }
        }
      }

      animationFrameId = requestAnimationFrame(render);
    };

    animationFrameId = requestAnimationFrame(render);

    // Subtle GPU-friendly scroll parallax on atmospheric fog layer
    let ticking = false;
    const handleScroll = () => {
      if (!ticking) {
        window.requestAnimationFrame(() => {
          if (parallaxLayerRef.current) {
            const scrollY = window.scrollY;
            parallaxLayerRef.current.style.transform = `translate3d(0, ${-(scrollY * 0.06)}px, 0)`;
          }
          ticking = false;
        });
        ticking = true;
      }
    };

    window.addEventListener('resize', setCanvasSize, { passive: true });
    window.addEventListener('scroll', handleScroll, { passive: true });

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', setCanvasSize);
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <div
      className="fixed inset-0 pointer-events-none z-0 overflow-hidden select-none"
      aria-hidden="true"
    >
      {/* LAYER 1: Deep Black & Midnight Navy Cinematic Base Gradient */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_60%_at_50%_-10%,#0c1938_0%,#050b1a_45%,#02040a_100%)]" />

      {/* LAYER 2: Slow-Moving Atmospheric Clouds, Fog & Faint Energy Streaks */}
      <div
        ref={parallaxLayerRef}
        className="absolute -inset-y-32 inset-x-0 will-change-transform"
      >
        {/* Drifting Midnight Cloud Nebula 1 */}
        <div className="cinematic-fog-1 absolute -top-24 -left-1/4 w-[130%] h-[520px] rounded-full bg-[radial-gradient(closest-side,rgba(29,78,216,0.13),rgba(30,27,75,0.06),transparent)] blur-3xl" />

        {/* Drifting Violet-Blue Atmospheric Mist 2 */}
        <div className="cinematic-fog-2 absolute top-[28%] -right-1/4 w-[120%] h-[480px] rounded-full bg-[radial-gradient(closest-side,rgba(109,40,217,0.10),rgba(37,99,235,0.05),transparent)] blur-3xl" />

        {/* Deep Horizon Fog 3 */}
        <div className="cinematic-fog-1 absolute bottom-0 left-1/4 w-[90%] h-[420px] rounded-full bg-[radial-gradient(closest-side,rgba(14,165,233,0.07),rgba(15,23,42,0.05),transparent)] blur-3xl" />

        {/* Faint Futuristic Energy Waves / Light Streaks */}
        <svg
          className="w-full h-full opacity-[0.14]"
          viewBox="0 0 1440 900"
          fill="none"
          preserveAspectRatio="xMidYMid slice"
        >
          <defs>
            <linearGradient id="energyWave1" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#3b82f6" stopOpacity="0" />
              <stop offset="35%" stopColor="#60a5fa" stopOpacity="0.45" />
              <stop offset="65%" stopColor="#8b5cf6" stopOpacity="0.35" />
              <stop offset="100%" stopColor="#3b82f6" stopOpacity="0" />
            </linearGradient>
            <linearGradient id="energyWave2" x1="100%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#6366f1" stopOpacity="0" />
              <stop offset="50%" stopColor="#38bdf8" stopOpacity="0.3" />
              <stop offset="100%" stopColor="#6366f1" stopOpacity="0" />
            </linearGradient>
          </defs>
          <path
            d="M-100 260 C 320 140, 720 380, 1540 190"
            stroke="url(#energyWave1)"
            strokeWidth="1.5"
            className="cinematic-energy-streak"
          />
          <path
            d="M-100 580 C 480 420, 960 690, 1540 490"
            stroke="url(#energyWave2)"
            strokeWidth="1"
            className="cinematic-energy-streak-slow"
          />
        </svg>
      </div>

      {/* LAYER 3 & 4: Drifting Particles & Procedural Distant Lightning Canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full pointer-events-none"
      />

      {/* LAYER 4b: Subtle Atmospheric Flash Glow Overlay */}
      <div
        ref={flashOverlayRef}
        className="absolute inset-0 bg-[radial-gradient(circle_at_50%_20%,rgba(96,165,250,0.35),rgba(139,92,246,0.12)_55%,transparent_85%)] opacity-0 transition-opacity duration-75 pointer-events-none"
      />

      {/* LAYER 5: Subtle Vignette to Guarantee Crisp Foreground Text Readability */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_35%,rgba(2,4,10,0.65)_100%)]" />
    </div>
  );
};
