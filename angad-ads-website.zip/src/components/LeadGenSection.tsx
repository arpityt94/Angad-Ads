import React from 'react';
import { Send, Phone, ArrowUpRight, Target, Users, Filter, BarChart, ShieldAlert } from 'lucide-react';
import { trackTelegramClick, trackPhoneCall } from '../utils/pixel';

interface LeadGenSectionProps {
  onOpenCallModal?: () => void;
}

export const LeadGenSection: React.FC<LeadGenSectionProps> = ({ onOpenCallModal }) => {
  const steps = [
    {
      title: 'Audience Discovery',
      desc: 'Aapke actual buyers aur high-intent customers ki demographics identify ki jaati hain.',
      icon: <Users className="w-5 h-5 text-blue-400" />,
    },
    {
      title: 'Lead Form & Funnel',
      desc: 'Meta Instant Lead Forms ya WhatsApp messaging campaigns ke through clean funnel create hoti hai.',
      icon: <Filter className="w-5 h-5 text-indigo-400" />,
    },
    {
      title: 'Creative & Hook Strategy',
      desc: 'Catchy ad creatives aur clear Call-To-Action jo relevant enquiries ko attract karein.',
      icon: <Target className="w-5 h-5 text-violet-400" />,
    },
    {
      title: 'Data-Backed Refinement',
      desc: 'Cost Per Lead (CPL) aur lead flow ko regular optimize karke budget efficiency improve karna.',
      icon: <BarChart className="w-5 h-5 text-emerald-400" />,
    },
  ];

  return (
    <section className="py-20 bg-transparent relative z-10 overflow-hidden cinematic-section-reveal">
      {/* Background glow */}
      <div className="absolute top-1/2 left-1/3 -translate-y-1/2 w-[500px] h-[350px] bg-gradient-to-tr from-blue-700/15 via-indigo-600/10 to-transparent blur-[130px] pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="text-xs font-semibold tracking-wider uppercase text-blue-400 bg-blue-950/50 border border-blue-500/20 px-3 py-1 rounded-md inline-block mb-3">
            LEAD GENERATION SPECIALTY
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mb-4 text-balance">
            Business Ke Liye Quality Leads Chahiye?
          </h2>
          <p className="text-base sm:text-lg text-slate-300 leading-relaxed text-balance">
            Lead generation campaigns ko aapke business, offer, audience aur budget ke according plan kiya ja sakta hai. Apni requirements share karein aur suitable campaign strategy discuss karein.
          </p>
        </div>

        {/* 4 Pillars of Lead Gen */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-10">
          {steps.map((st) => (
            <div
              key={st.title}
              className="p-6 rounded-2xl glass-card glass-card-hover flex flex-col justify-between"
            >
              <div>
                <div className="w-11 h-11 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center mb-4">
                  {st.icon}
                </div>
                <h3 className="text-base font-bold text-white mb-2">{st.title}</h3>
                <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                  {st.desc}
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-800/80 text-[11px] font-mono text-blue-400">
                Pillar Setup
              </div>
            </div>
          ))}
        </div>

        {/* CTAs & Disclaimers */}
        <div className="rounded-3xl glass-card p-6 sm:p-10 border border-slate-700/80 flex flex-col items-center text-center max-w-3xl mx-auto">
          <h3 className="text-xl sm:text-2xl font-bold text-white mb-3">
            Apne Business Ke Liye Suitable Strategy Plan Karein
          </h3>
          <p className="text-xs sm:text-sm text-slate-300 mb-8 max-w-xl">
            Telegram par apni requirements bhejein ya direct call karke advertising options par baat karein.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3.5 w-full sm:w-auto mb-6">
            <a
              href="https://t.me/Angad_ads"
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => trackTelegramClick('Lead Gen Section CTA')}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl font-bold text-sm text-white bg-gradient-to-r from-blue-600 via-indigo-600 to-violet-600 hover:from-blue-500 hover:to-violet-500 shadow-xl shadow-blue-600/30 transition-all duration-200 active:scale-95 group"
            >
              <Send className="w-4 h-4 text-blue-200 group-hover:translate-x-0.5 transition-transform" />
              <span>Telegram Par Baat Karein</span>
              <ArrowUpRight className="w-4 h-4 text-blue-200 opacity-80" />
            </a>

            <a
              href="tel:+917888870589"
              onClick={(e) => {
                trackPhoneCall('+91 7888870589', 'Primary', 'Lead Gen Section Call CTA');
                if (onOpenCallModal) {
                  e.preventDefault();
                  onOpenCallModal();
                }
              }}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl font-semibold text-sm text-slate-200 bg-slate-900 border border-slate-700 hover:border-emerald-500 transition-all duration-200 active:scale-95"
            >
              <Phone className="w-4 h-4 text-emerald-400" />
              <span>Direct Call Karein</span>
            </a>
          </div>

          {/* Transparent Result Disclaimer (Mandatory) */}
          <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-900 text-xs text-slate-400 flex items-start sm:items-center gap-2.5 max-w-2xl text-left">
            <ShieldAlert className="w-4 h-4 text-slate-400 shrink-0 mt-0.5 sm:mt-0" />
            <p>
              <strong className="text-slate-300">Important Disclaimer:</strong> Koi bhi fixed number of leads, guaranteed sales ya guaranteed conversion quality ka fake vaada nahi kiya jata. Results aapke product offer, target audience, budget, creative aur market competition par nirbhar karte hain.
            </p>
          </div>
        </div>

      </div>
    </section>
  );
};
