import React, { useState } from 'react';
import { Send, Phone, CheckCircle2, Users, Target, ArrowUpRight, BarChart3, ShieldCheck, Zap, GraduationCap, Layers, Sparkles } from 'lucide-react';
import { trackTelegramClick, trackPhoneCall } from '../utils/pixel';

interface HeroProps {
  onOpenCallModal?: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenCallModal }) => {
  const [timeframe, setTimeframe] = useState<'7d' | '14d' | '30d'>('14d');

  const statsByTimeframe = {
    '7d': {
      leads: '112',
      reach: '58,400',
      ctr: '3.18%',
      cpl: '₹14.20',
      spend: '₹1,590',
      chartBars: [45, 62, 58, 85, 78, 92, 98],
      wavePath: 'M 0 58 Q 45 48, 90 42 T 180 28 T 270 18 T 360 8',
    },
    '14d': {
      leads: '248',
      reach: '124,500',
      ctr: '3.42%',
      cpl: '₹12.80',
      spend: '₹3,174',
      chartBars: [32, 45, 54, 62, 70, 68, 75, 82, 88, 79, 86, 91, 95, 100],
      wavePath: 'M 0 64 Q 45 52, 90 44 T 180 32 T 270 16 T 360 6',
    },
    '30d': {
      leads: '530',
      reach: '280,000',
      ctr: '3.65%',
      cpl: '₹11.90',
      spend: '₹6,307',
      chartBars: [28, 35, 42, 50, 48, 55, 62, 68, 72, 75, 80, 84, 82, 88, 90, 85, 92, 94, 98, 91, 95, 99, 100],
      wavePath: 'M 0 66 Q 45 55, 90 40 T 180 26 T 270 14 T 360 4',
    },
  };

  const currentStats = statsByTimeframe[timeframe];

  return (
    <section id="home" className="relative pt-28 pb-16 md:pt-36 md:pb-24 overflow-hidden">
      {/* Ambient Hero Spotlight Glows */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[550px] md:w-[860px] h-[350px] md:h-[480px] bg-gradient-to-tr from-blue-700/20 via-indigo-600/15 to-violet-600/15 blur-[130px] pointer-events-none -z-10" />
      <div className="absolute top-12 right-8 w-80 h-80 bg-blue-500/12 blur-[100px] pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-10 items-center">
          
          {/* Left Column: Headline, Hinglish Copy, CTAs */}
          <div className="lg:col-span-7 flex flex-col items-start text-left">
            
            {/* Top Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-md bg-blue-950/75 border border-blue-500/40 text-blue-300 text-xs font-bold tracking-wider uppercase mb-5 shadow-sm shadow-blue-950/50">
              <Zap className="w-3.5 h-3.5 text-blue-400" />
              <span>META ADS SETUP • TRAINING • LEAD GENERATION</span>
            </div>

            {/* Main Headline with Electric-Blue Light Sweep on Second Line */}
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-[3.35rem] font-extrabold text-white leading-[1.15] tracking-tight mb-3 text-balance">
              <span className="block">Business Ko Grow Karna Hai?</span>
              <span className="block mt-1.5 hero-light-sweep">
                Let's Talk Ads!
              </span>
            </h1>

            {/* Subtitle Preserving Setup + Training Positioning */}
            <p className="text-base sm:text-xl font-bold text-blue-200/95 tracking-tight mb-3 text-balance">
              Meta Ads Seekho Bhi, Apne Business Ke Liye Setup Bhi Karwao!
            </p>

            {/* Supporting Hinglish Copy */}
            <p className="text-sm sm:text-base md:text-lg text-slate-300/95 leading-relaxed max-w-2xl mb-8">
              Facebook aur Instagram Ads setup karwana hai ya khud Ads chalana seekhna hai? Dono ke liye humse contact karein. Apni requirements share karein aur apne budget ke according suitable solution discuss karein.
            </p>

            {/* CTAs Block */}
            <div className="w-full sm:w-auto flex flex-col sm:flex-row items-stretch sm:items-center gap-3.5 mb-8">
              <a
                href="https://t.me/Angad_ads"
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => trackTelegramClick('Hero Primary CTA')}
                className="inline-flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-xl font-semibold text-sm sm:text-base text-white bg-gradient-to-r from-blue-600 via-blue-700 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 shadow-xl shadow-blue-600/30 hover:shadow-blue-500/50 border border-blue-400/20 transition-all duration-200 active:scale-[0.98] group"
              >
                <Send className="w-4 h-4 text-blue-200 group-hover:translate-x-0.5 transition-transform" />
                <span>Telegram Par Message Karein</span>
                <ArrowUpRight className="w-4 h-4 text-blue-200 opacity-80" />
              </a>

              <a
                href="tel:+917888870589"
                onClick={(e) => {
                  trackPhoneCall('+91 7888870589', 'Primary', 'Hero Secondary CTA');
                  if (onOpenCallModal && window.innerWidth >= 640) {
                    e.preventDefault();
                    onOpenCallModal();
                  }
                }}
                className="inline-flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-xl font-semibold text-sm sm:text-base text-slate-100 bg-slate-900/90 hover:bg-slate-800 border border-slate-700 hover:border-blue-500/40 transition-all duration-200 active:scale-[0.98]"
              >
                <Phone className="w-4 h-4 text-emerald-400" />
                <span>Abhi Call Karein — 7888870589</span>
              </a>
            </div>

            {/* 3 Small Feature Labels */}
            <div className="w-full pt-4 border-t border-slate-800/80 grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs sm:text-sm text-slate-300">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-blue-400 shrink-0" />
                <span>Professional Meta Ads Setup</span>
              </div>
              <div className="flex items-center gap-2">
                <GraduationCap className="w-4 h-4 text-violet-400 shrink-0" />
                <span>Ads Setup Training &amp; Guidance</span>
              </div>
              <div className="flex items-center gap-2">
                <Target className="w-4 h-4 text-indigo-400 shrink-0" />
                <span>Lead Generation Campaigns</span>
              </div>
            </div>

          </div>

          {/* Right Column: Premium Animated Advertising Dashboard Visual with Floating Glass Panels */}
          <div className="lg:col-span-5 w-full relative">
            
            {/* Soft Blue & Violet Ambient Edge Lighting Behind Dashboard */}
            <div className="absolute -inset-2 rounded-3xl bg-gradient-to-tr from-blue-600/20 via-indigo-500/10 to-violet-600/20 blur-2xl pointer-events-none" />

            {/* Floating Glass Sub-Panel 1 (Top Right): Audience Targeting */}
            <div
              className="hidden sm:flex floating-panel-slow absolute -top-5 -right-3 z-20 items-center gap-2.5 px-3.5 py-2 rounded-xl bg-slate-950/90 backdrop-blur-md border border-blue-500/40 shadow-lg shadow-blue-950/60 pointer-events-none"
              aria-hidden="true"
            >
              <div className="w-7 h-7 rounded-lg bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
                <Layers className="w-3.5 h-3.5" />
              </div>
              <div>
                <div className="text-[10px] font-semibold uppercase tracking-wider text-blue-300">Smart Targeting</div>
                <div className="text-xs font-bold text-white">Custom Audience Ready</div>
              </div>
            </div>

            {/* Floating Glass Sub-Panel 2 (Bottom Left): Creative Strategy */}
            <div
              className="hidden sm:flex floating-panel-delayed absolute -bottom-4 -left-3 z-20 items-center gap-2.5 px-3.5 py-2 rounded-xl bg-slate-950/90 backdrop-blur-md border border-violet-500/40 shadow-lg shadow-violet-950/60 pointer-events-none"
              aria-hidden="true"
            >
              <div className="w-7 h-7 rounded-lg bg-violet-600/20 border border-violet-500/30 flex items-center justify-center text-violet-400">
                <Sparkles className="w-3.5 h-3.5" />
              </div>
              <div>
                <div className="text-[10px] font-semibold uppercase tracking-wider text-violet-300">Ad Strategy</div>
                <div className="text-xs font-bold text-white">Setup + 1:1 Training</div>
              </div>
            </div>

            {/* Main Dashboard Container */}
            <div className="relative mx-auto max-w-md lg:max-w-none rounded-2xl glass-card p-5 sm:p-6 shadow-2xl border border-blue-500/30 overflow-hidden group">
              
              {/* Soft Blue Edge Lighting Top Bar */}
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-500 via-cyan-400 to-violet-500" />

              {/* Decorative Subtle Animated Particles Inside Card */}
              <div className="absolute top-12 right-10 w-1.5 h-1.5 rounded-full bg-blue-400/40 pointer-events-none" aria-hidden="true" />
              <div className="absolute bottom-20 left-8 w-1 h-1 rounded-full bg-violet-400/40 pointer-events-none" aria-hidden="true" />

              {/* Dashboard Header */}
              <div className="flex items-center justify-between pb-4 border-b border-slate-800/80 mb-4">
                <div className="flex items-center gap-2">
                  <BarChart3 className="w-4 h-4 text-blue-400" />
                  <span className="text-xs font-semibold text-slate-200 tracking-wide">Campaign Manager Preview</span>
                </div>
                
                {/* Interactive Timeframe Selector */}
                <div className="flex items-center p-0.5 rounded-lg bg-slate-900/90 border border-slate-800 text-[11px]">
                  {(['7d', '14d', '30d'] as const).map((t) => (
                    <button
                      key={t}
                      type="button"
                      onClick={() => setTimeframe(t)}
                      className={`px-2.5 py-1 rounded-md font-medium transition-all whitespace-nowrap ${
                        timeframe === t
                          ? 'bg-blue-600 text-white shadow-xs'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {t.toUpperCase()}
                    </button>
                  ))}
                </div>
              </div>

              {/* Campaign Architecture Status Bar */}
              <div className="flex items-center justify-between px-3 py-2 rounded-lg bg-blue-950/40 border border-blue-800/40 mb-4 text-xs">
                <div className="flex items-center gap-2">
                  <span className="text-blue-400 font-medium">Mode:</span>
                  <span className="text-slate-200 font-semibold">Setup &amp; Practical Training</span>
                </div>
                <span className="text-cyan-300 font-mono text-[11px]">
                   Simulation
                </span>
              </div>

              {/* Metric Cards Grid */}
              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="p-3 rounded-xl bg-slate-900/85 border border-slate-800/90 hover:border-blue-500/30 transition-colors">
                  <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
                    <span>Relevant Leads</span>
                    <Users className="w-3.5 h-3.5 text-blue-400" />
                  </div>
                  <div className="text-xl sm:text-2xl font-bold text-white tabular-nums">
                    {currentStats.leads}
                  </div>
                  <div className="text-[11px] text-emerald-400 font-medium mt-0.5">
                    Targeted inquiries
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-900/85 border border-slate-800/90 hover:border-indigo-500/30 transition-colors">
                  <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
                    <span>Target Reach</span>
                    <BarChart3 className="w-3.5 h-3.5 text-indigo-400" />
                  </div>
                  <div className="text-xl sm:text-2xl font-bold text-white tabular-nums">
                    {currentStats.reach}
                  </div>
                  <div className="text-[11px] text-slate-400 font-medium mt-0.5">
                    CTR: <span className="text-white font-semibold tabular-nums">{currentStats.ctr}</span>
                  </div>
                </div>
              </div>

              {/* Interactive Moving Chart Graphic (SVG Wave + Bars) */}
              <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800/80 mb-3 relative overflow-hidden">
                <div className="flex items-center justify-between text-xs text-slate-300 mb-2 relative z-10">
                  <span className="font-medium">Campaign Structure &amp; Flow</span>
                  <span className="text-slate-400 text-[11px] tabular-nums">
                    Est. CPL: <strong className="text-emerald-400">{currentStats.cpl}</strong>
                  </span>
                </div>

                {/* Subtle Animated SVG Spline Overlay */}
                <svg
                  className="absolute inset-x-3 bottom-6 h-16 w-[calc(100%-1.5rem)] pointer-events-none opacity-45"
                  viewBox="0 0 360 70"
                  fill="none"
                  preserveAspectRatio="none"
                  aria-hidden="true"
                >
                  <path
                    d={currentStats.wavePath}
                    stroke="#38bdf8"
                    strokeWidth="2"
                    strokeLinecap="round"
                  />
                </svg>
                
                {/* Visual Bars */}
                <div className="h-20 flex items-end gap-1.5 pt-2 pb-1 relative z-10">
                  {currentStats.chartBars.map((val, idx) => (
                    <div
                      key={idx}
                      className="flex-1 bg-gradient-to-t from-blue-600/40 via-blue-500/85 to-cyan-300 rounded-t-sm transition-all duration-500 hover:brightness-125"
                      style={{ height: `${val}%` }}
                      title={`Simulation index ${idx + 1}: ${val}%`}
                    />
                  ))}
                </div>
                <div className="flex justify-between text-[10px] text-slate-400 font-mono mt-1 relative z-10">
                  <span>Setup</span>
                  <span>Audience Targeting</span>
                  <span>Optimization</span>
                </div>
              </div>

              {/* Illustrative Demo Note */}
              <div className="flex items-center gap-2 text-[11px] text-slate-400 pt-1">
                <ShieldCheck className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                <span>Dashboard numbers illustrative demo hain, real client results nahi.</span>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
