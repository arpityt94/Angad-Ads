import React from 'react';
import { Phone, Send, Clock, ShieldCheck, ArrowUpRight, MessageCircle } from 'lucide-react';
import { trackTelegramClick, trackPhoneCall } from '../utils/pixel';

export const ContactSection: React.FC = () => {
  return (
    <section id="contact" className="py-20 bg-transparent relative z-10 border-t border-slate-800/70 cinematic-section-reveal">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="text-xs font-semibold tracking-wider uppercase text-emerald-400 bg-emerald-950/50 border border-emerald-500/20 px-3 py-1 rounded-md inline-block mb-3">
            DIRECT COMMUNICATION
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mb-4 text-balance">
            Dono Numbers Par Direct Call Karein
          </h2>
          <p className="text-base text-slate-300 leading-relaxed text-balance">
            Kisi bhi time apni requirements discuss karne ke liye hume Telegram par message bhejein ya diye gaye dono numbers par direct call lagayein.
          </p>
        </div>

        {/* 3 Contact Cards: 2 Phone Lines + 1 Telegram Channel */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          
          {/* Card 1: Primary Line */}
          <div className="rounded-3xl glass-card p-6 sm:p-7 glass-card-hover border border-emerald-500/30 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-5">
                <div className="w-12 h-12 rounded-2xl bg-emerald-950/80 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                  <Phone className="w-6 h-6" />
                </div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-400 bg-emerald-950/80 px-2.5 py-1 rounded-md border border-emerald-500/30">
                  Primary Line
                </span>
              </div>

              <h3 className="text-lg font-bold text-white mb-1">
                Main Calling Number
              </h3>
              <p className="text-xs text-slate-400 mb-4">
                Meta Ads setup, consultation &amp; campaign queries ke liye primary direct line.
              </p>

              <div className="text-xl sm:text-2xl font-extrabold text-white font-mono tracking-tight mb-6">
                +91 7888870589
              </div>
            </div>

            <a
              href="tel:+917888870589"
              onClick={() => trackPhoneCall('+91 7888870589', 'Primary', 'Contact Section Card')}
              className="w-full inline-flex items-center justify-center gap-2 py-3.5 px-4 rounded-xl font-bold text-sm bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-600/25 active:scale-95 transition-all"
              aria-label="Call Primary Number +917888870589"
            >
              <Phone className="w-4 h-4" />
              <span>Call +91 7888870589</span>
            </a>
          </div>

          {/* Card 2: Secondary Line */}
          <div className="rounded-3xl glass-card p-6 sm:p-7 glass-card-hover border border-blue-500/30 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-5">
                <div className="w-12 h-12 rounded-2xl bg-blue-950/80 border border-blue-500/40 flex items-center justify-center text-blue-400">
                  <Phone className="w-6 h-6" />
                </div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-blue-400 bg-blue-950/80 px-2.5 py-1 rounded-md border border-blue-500/30">
                  Support Line
                </span>
              </div>

              <h3 className="text-lg font-bold text-white mb-1">
                Secondary Calling Number
              </h3>
              <p className="text-xs text-slate-400 mb-4">
                Alternate line for quick response, student training inquiries aur setup follow-ups.
              </p>

              <div className="text-xl sm:text-2xl font-extrabold text-white font-mono tracking-tight mb-6">
                +91 8847415750
              </div>
            </div>

            <a
              href="tel:+918847415750"
              onClick={() => trackPhoneCall('+91 8847415750', 'Secondary', 'Contact Section Card')}
              className="w-full inline-flex items-center justify-center gap-2 py-3.5 px-4 rounded-xl font-bold text-sm bg-blue-600 hover:bg-blue-500 text-white shadow-lg shadow-blue-600/25 active:scale-95 transition-all"
              aria-label="Call Secondary Number +918847415750"
            >
              <Phone className="w-4 h-4" />
              <span>Call +91 8847415750</span>
            </a>
          </div>

          {/* Card 3: Telegram Official */}
          <div className="rounded-3xl glass-card p-6 sm:p-7 glass-card-hover border border-indigo-500/30 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-5">
                <div className="w-12 h-12 rounded-2xl bg-indigo-950/80 border border-indigo-500/40 flex items-center justify-center text-indigo-400">
                  <Send className="w-6 h-6" />
                </div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-400 bg-indigo-950/80 px-2.5 py-1 rounded-md border border-indigo-500/30">
                  24/7 Chat
                </span>
              </div>

              <h3 className="text-lg font-bold text-white mb-1">
                Official Telegram Handle
              </h3>
              <p className="text-xs text-slate-400 mb-4">
                Voice notes, screenshots aur requirements directly share karne ke liye best channel.
              </p>

              <div className="text-xl sm:text-2xl font-extrabold text-white tracking-tight mb-6 flex items-center gap-1.5">
                <span className="text-blue-400">@</span>Angad_ads
              </div>
            </div>

            <a
              href="https://t.me/Angad_ads"
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => trackTelegramClick('Contact Section Telegram Card')}
              className="w-full inline-flex items-center justify-center gap-2 py-3.5 px-4 rounded-xl font-bold text-sm bg-gradient-to-r from-blue-600 via-indigo-600 to-violet-600 hover:from-blue-500 hover:to-violet-500 text-white shadow-lg shadow-blue-600/25 active:scale-95 transition-all group"
            >
              <Send className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
              <span>Telegram Par Message Karein</span>
              <ArrowUpRight className="w-4 h-4 opacity-80" />
            </a>
          </div>

        </div>

        {/* Reassurance strip */}
        <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 text-xs text-slate-400 flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Calling hours: Subah 9:00 AM se Raat 10:00 PM (All 7 Days).</span>
          </div>
          <div className="flex items-center gap-2 text-slate-300">
            <ShieldCheck className="w-4 h-4 text-blue-400 shrink-0" />
            <span>Telegram par kabhi bhi message drop kar sakte hain.</span>
          </div>
        </div>

      </div>
    </section>
  );
};
