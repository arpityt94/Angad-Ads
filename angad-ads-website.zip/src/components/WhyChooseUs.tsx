import React from 'react';
import { Target, MessageSquare, Settings2, LineChart, Send, ArrowUpRight } from 'lucide-react';
import { trackTelegramClick } from '../utils/pixel';

export const WhyChooseUs: React.FC = () => {
  const points = [
    {
      icon: <Target className="w-6 h-6 text-blue-400" />,
      title: 'Business-Focused Planning',
      description: 'Aapke business goals aur requirements ke according campaign planning.',
      benefit: 'Target-Oriented',
    },
    {
      icon: <MessageSquare className="w-6 h-6 text-indigo-400" />,
      title: 'Transparent Communication',
      description: 'Service fee, advertising budget aur work scope par clear discussion.',
      benefit: '100% Clarity',
    },
    {
      icon: <Settings2 className="w-6 h-6 text-violet-400" />,
      title: 'Customized Campaign Setup',
      description: 'Business category aur campaign objectives ke according suitable setup.',
      benefit: 'Custom Funnels',
    },
    {
      icon: <LineChart className="w-6 h-6 text-emerald-400" />,
      title: 'Performance Review',
      description: 'Available results ko review karke campaign improvement ke opportunities identify karein.',
      benefit: 'Data-Driven Growth',
    },
  ];

  return (
    <section className="py-20 bg-[#060b18]/50 relative z-10 border-y border-slate-800/70 cinematic-section-reveal">
      {/* Background soft ambient radial glow */}
      <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-96 h-96 bg-blue-600/10 blur-[120px] pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs font-semibold tracking-wider uppercase text-indigo-400 bg-indigo-950/50 border border-indigo-500/20 px-3 py-1 rounded-md inline-block mb-3">
            WHY CHOOSE ANGAD ADS
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mb-4 text-balance">
            Ads Sirf Run Nahi, Strategy Ke Saath Plan Karein.
          </h2>
          <p className="text-base sm:text-lg text-slate-300 leading-relaxed text-balance">
            Har business ki requirements alag hoti hain. Isliye campaign approach bhi aapke goals aur budget ko dhyan mein rakhkar discuss honi chahiye.
          </p>
        </div>

        {/* 4 Feature Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-14">
          {points.map((pt, idx) => (
            <div
              key={pt.title}
              className="p-6 rounded-2xl glass-card glass-card-hover flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center mb-5">
                  {pt.icon}
                </div>
                <div className="text-xs font-mono text-blue-400 mb-1">Feature 0{idx + 1}</div>
                <h3 className="text-lg font-bold text-white mb-2">{pt.title}</h3>
                <p className="text-sm text-slate-300/90 leading-relaxed">
                  {pt.description}
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-slate-800 text-xs font-medium text-slate-400 flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-400" />
                <span>{pt.benefit}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Section CTA Button */}
        <div className="flex justify-center">
          <a
            href="https://t.me/Angad_ads"
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => trackTelegramClick('Why Choose Us CTA')}
            className="inline-flex items-center gap-2.5 px-7 py-4 rounded-xl font-semibold text-sm sm:text-base text-white bg-gradient-to-r from-blue-600 via-indigo-600 to-violet-600 hover:from-blue-500 hover:to-violet-500 shadow-xl shadow-blue-600/25 hover:shadow-indigo-500/40 transition-all duration-200 active:scale-95 group"
          >
            <Send className="w-4 h-4 text-blue-200 group-hover:translate-x-0.5 transition-transform" />
            <span>Apni Requirements Share Karein</span>
            <ArrowUpRight className="w-4 h-4 text-blue-200 opacity-80" />
          </a>
        </div>

      </div>
    </section>
  );
};
