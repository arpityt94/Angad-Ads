import React from 'react';
import { Send, Phone, ArrowUpRight, ShieldCheck, Zap } from 'lucide-react';
import { trackTelegramClick, trackPhoneCall } from '../utils/pixel';

interface FinalCTAProps {
  onOpenCallModal?: () => void;
}

export const FinalCTA: React.FC<FinalCTAProps> = ({ onOpenCallModal }) => {
  return (
    <section className="py-20 relative z-10 overflow-hidden cinematic-section-reveal">
      {/* Ambient Glow backgrounds */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-gradient-to-r from-blue-600/20 via-indigo-600/25 to-violet-600/20 blur-[130px] pointer-events-none -z-10" />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-3xl p-8 sm:p-12 md:p-16 bg-gradient-to-br from-slate-900/90 via-[#0a1128]/95 to-slate-900/90 border border-blue-500/30 shadow-2xl shadow-blue-950/50 overflow-hidden text-center">
          
          {/* Subtle Top Gradient Accent Border */}
          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-500 via-indigo-400 to-violet-500" />

          {/* Decorative Corner Badge */}
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-blue-950/70 border border-blue-500/30 text-blue-300 text-xs font-semibold uppercase tracking-wider mb-6">
            <Zap className="w-3.5 h-3.5 text-blue-400" />
            <span>LET'S TALK ADS</span>
          </div>

          {/* Main Headline */}
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight mb-5 max-w-3xl mx-auto leading-tight text-balance">
            Ads Se Related Koi Bhi Jankari Chahiye?
          </h2>

          {/* Supporting Hinglish Copy */}
          <p className="text-base sm:text-lg text-slate-300 max-w-2xl mx-auto leading-relaxed mb-10 text-balance">
            Meta Ads setup karwana ho, khud ads chalana seekhna ho ya lead generation campaign plan karwana ho — apni requirements share karein.
          </p>

          {/* Conversion Action Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 max-w-xl mx-auto mb-8">
            <a
              href="https://t.me/Angad_ads"
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => trackTelegramClick('Final CTA Section')}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-8 py-4 rounded-xl font-bold text-sm sm:text-base text-white bg-gradient-to-r from-blue-600 via-blue-500 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 shadow-xl shadow-blue-600/35 hover:shadow-blue-500/50 transition-all duration-200 active:scale-95 group"
            >
              <Send className="w-4 h-4 text-white group-hover:translate-x-0.5 transition-transform" />
              <span>Telegram Par Message Karein</span>
              <ArrowUpRight className="w-4 h-4 text-blue-200" />
            </a>

            <a
              href="tel:+917888870589"
              onClick={(e) => {
                trackPhoneCall('+91 7888870589', 'Primary', 'Final CTA Call Button');
                if (onOpenCallModal) {
                  e.preventDefault();
                  onOpenCallModal();
                }
              }}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-7 py-4 rounded-xl font-semibold text-sm sm:text-base text-slate-100 bg-slate-900/90 hover:bg-slate-800 border border-slate-700 hover:border-slate-600 transition-all duration-200 active:scale-95"
            >
              <Phone className="w-4 h-4 text-emerald-400" />
              <span>Call Now — 7888870589</span>
            </a>
          </div>

          {/* Direct calling lines quick selector */}
          <div className="text-xs text-slate-400 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 pt-2 border-t border-slate-800/60 max-w-lg mx-auto">
            <span>Direct Call Lines:</span>
            <a
              href="tel:+917888870589"
              onClick={() => trackPhoneCall('+91 7888870589', 'Primary', 'Final CTA Footer Line 1')}
              className="text-emerald-400 hover:underline font-mono font-semibold"
            >
              +91 7888870589 (L1)
            </a>
            <span className="text-slate-600">·</span>
            <a
              href="tel:+918847415750"
              onClick={() => trackPhoneCall('+91 8847415750', 'Secondary', 'Final CTA Footer Line 2')}
              className="text-blue-400 hover:underline font-mono font-semibold"
            >
              +91 8847415750 (L2)
            </a>
          </div>

        </div>
      </div>
    </section>
  );
};
