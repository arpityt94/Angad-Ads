import React from 'react';
import { GraduationCap, Layers, Send, ArrowUpRight, Check, Sparkles } from 'lucide-react';
import { trackTelegramClick, trackIntentEvent } from '../utils/pixel';

export const LearnOrSetupSection: React.FC = () => {
  return (
    <section className="py-20 bg-[#040815]/55 relative z-10 border-b border-slate-800/70 cinematic-section-reveal">
      {/* Ambient background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[350px] bg-gradient-to-r from-blue-700/10 via-violet-600/15 to-blue-700/10 blur-[130px] pointer-events-none -z-10" />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="text-xs font-semibold tracking-wider uppercase text-violet-400 bg-violet-950/50 border border-violet-500/20 px-3 py-1 rounded-md inline-block mb-3">
            CHOOSE YOUR PATH
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mb-4 text-balance">
            Seekhna Chahte Ho Ya Setup Karwana?
          </h2>
          <p className="text-base text-slate-300 leading-relaxed text-balance">
            Dono requirements ke liye hum aapko personalized solution provide karte hain. Jo aapke liye better ho, wo select karein.
          </p>
        </div>

        {/* 2 Large Side-by-Side Premium Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-stretch">
          
          {/* CARD A: Training */}
          <div className="rounded-3xl glass-card p-7 sm:p-9 glass-card-hover border border-violet-500/30 flex flex-col justify-between relative overflow-hidden group">
            {/* Top decorative gradient bar */}
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-violet-500 to-indigo-500" />
            
            <div>
              <div className="flex items-center justify-between mb-6">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-violet-950 to-indigo-900 border border-violet-500/40 flex items-center justify-center text-violet-300 shadow-lg shadow-violet-900/30">
                  <GraduationCap className="w-7 h-7" />
                </div>
                <span className="text-xs font-semibold text-violet-300 px-3 py-1 rounded-full bg-violet-950/80 border border-violet-500/30">
                  Option 01 • Training
                </span>
              </div>

              <h3 className="text-2xl font-extrabold text-white mb-3 group-hover:text-violet-300 transition-colors">
                Khud Meta Ads Seekhna Hai?
              </h3>

              <p className="text-sm sm:text-base text-slate-300 leading-relaxed mb-6">
                Ads setup, campaign structure, audience targeting aur advertising ke basics samajhne ke liye training aur guidance ke baare mein poochhein.
              </p>

              <div className="space-y-2.5 mb-8">
                <div className="flex items-center gap-2 text-xs sm:text-sm text-slate-300">
                  <Check className="w-4 h-4 text-violet-400 shrink-0" />
                  <span>Meta Ads Manager interface &amp; account setup</span>
                </div>
                <div className="flex items-center gap-2 text-xs sm:text-sm text-slate-300">
                  <Check className="w-4 h-4 text-violet-400 shrink-0" />
                  <span>Audience targeting &amp; custom demographics</span>
                </div>
                <div className="flex items-center gap-2 text-xs sm:text-sm text-slate-300">
                  <Check className="w-4 h-4 text-violet-400 shrink-0" />
                  <span>Ad creatives, copywriting &amp; basic optimization</span>
                </div>
              </div>
            </div>

            <div className="pt-6 border-t border-slate-800/80">
              <a
                href="https://t.me/Angad_ads"
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => {
                  trackTelegramClick('LearnOrSetup - Training Option');
                  trackIntentEvent('Training', 'LearnOrSetupSection');
                }}
                className="w-full inline-flex items-center justify-center gap-2 px-6 py-4 rounded-xl font-bold text-sm sm:text-base text-white bg-gradient-to-r from-violet-600 via-indigo-600 to-blue-600 hover:from-violet-500 hover:to-blue-500 shadow-xl shadow-violet-600/30 transition-all duration-200 active:scale-95 group/btn"
              >
                <Send className="w-4 h-4 text-violet-200 group-hover/btn:translate-x-0.5 transition-transform" />
                <span>Training Ke Liye Contact Karein</span>
                <ArrowUpRight className="w-4 h-4 text-violet-200 opacity-80" />
              </a>
            </div>
          </div>

          {/* CARD B: Done-For-You Setup */}
          <div className="rounded-3xl glass-card p-7 sm:p-9 glass-card-hover border border-blue-500/30 flex flex-col justify-between relative overflow-hidden group">
            {/* Top decorative gradient bar */}
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-500 to-cyan-500" />

            <div>
              <div className="flex items-center justify-between mb-6">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-blue-950 to-indigo-900 border border-blue-500/40 flex items-center justify-center text-blue-300 shadow-lg shadow-blue-900/30">
                  <Layers className="w-7 h-7" />
                </div>
                <span className="text-xs font-semibold text-blue-300 px-3 py-1 rounded-full bg-blue-950/80 border border-blue-500/30">
                  Option 02 • Done-For-You
                </span>
              </div>

              <h3 className="text-2xl font-extrabold text-white mb-3 group-hover:text-blue-300 transition-colors">
                Ads Setup Khud Nahi Karna?
              </h3>

              <p className="text-sm sm:text-base text-slate-300 leading-relaxed mb-6">
                Apne business ke liye Facebook aur Instagram Ads setup karwane aur lead generation strategy discuss karne ke liye contact karein.
              </p>

              <div className="space-y-2.5 mb-8">
                <div className="flex items-center gap-2 text-xs sm:text-sm text-slate-300">
                  <Check className="w-4 h-4 text-blue-400 shrink-0" />
                  <span>End-to-end professional campaign launch</span>
                </div>
                <div className="flex items-center gap-2 text-xs sm:text-sm text-slate-300">
                  <Check className="w-4 h-4 text-blue-400 shrink-0" />
                  <span>High-intent lead generation forms &amp; tracking</span>
                </div>
                <div className="flex items-center gap-2 text-xs sm:text-sm text-slate-300">
                  <Check className="w-4 h-4 text-blue-400 shrink-0" />
                  <span>Campaign monitoring &amp; performance optimization</span>
                </div>
              </div>
            </div>

            <div className="pt-6 border-t border-slate-800/80">
              <a
                href="https://t.me/Angad_ads"
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => {
                  trackTelegramClick('LearnOrSetup - Setup DFY Option');
                  trackIntentEvent('Setup', 'LearnOrSetupSection');
                }}
                className="w-full inline-flex items-center justify-center gap-2 px-6 py-4 rounded-xl font-bold text-sm sm:text-base text-white bg-gradient-to-r from-blue-600 via-indigo-600 to-violet-600 hover:from-blue-500 hover:to-violet-500 shadow-xl shadow-blue-600/30 transition-all duration-200 active:scale-95 group/btn"
              >
                <Send className="w-4 h-4 text-blue-200 group-hover/btn:translate-x-0.5 transition-transform" />
                <span>Setup Karwane Ke Liye Contact Karein</span>
                <ArrowUpRight className="w-4 h-4 text-blue-200 opacity-80" />
              </a>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
