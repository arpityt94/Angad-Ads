import React from 'react';
import { Send, Phone, ArrowUpRight, ShieldAlert } from 'lucide-react';
import { trackTelegramClick, trackPhoneCall } from '../utils/pixel';

interface FooterProps {
  onOpenLegal: (tab: 'privacy' | 'terms') => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenLegal }) => {
  return (
    <footer className="bg-[#02050e]/88 backdrop-blur-md relative z-10 border-t border-slate-800/80 pt-16 pb-28 md:pb-16 text-slate-400 text-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 pb-12 border-b border-slate-800/80">
          
          {/* Brand Col */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white font-mono font-bold text-sm shadow-md">
                A
              </div>
              <span className="text-xl font-extrabold text-white tracking-tight">
                ANGAD<span className="text-blue-500">ADS</span>
              </span>
            </div>

            <p className="text-slate-300 font-medium text-sm">
              Meta Ads Setup | Ads Training | Campaign Strategy | Digital Advertising
            </p>

            <p className="text-xs text-slate-400 max-w-sm leading-relaxed">
              Facebook aur Instagram ads ke through business inquiries aur campaign performance optimization ke liye dedicated support.
            </p>

            <div className="pt-2 flex items-center gap-3">
              <a
                href="https://t.me/Angad_ads"
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => trackTelegramClick('Footer Telegram Pill')}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-950/60 border border-blue-500/30 text-blue-300 text-xs font-semibold hover:bg-blue-900/60 transition-colors"
              >
                <Send className="w-3.5 h-3.5" />
                <span>@Angad_ads</span>
              </a>

              <a
                href="tel:+917888870589"
                onClick={() => trackPhoneCall('+91 7888870589', 'Primary', 'Footer Phone Pill')}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 text-xs font-medium hover:text-white transition-colors"
              >
                <Phone className="w-3.5 h-3.5 text-emerald-400" />
                <span>+91 7888870589</span>
              </a>
            </div>
          </div>

          {/* Quick Links Col */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">Quick Navigation</h4>
            <ul className="space-y-2 text-xs sm:text-sm">
              <li>
                <a href="#home" className="hover:text-blue-400 transition-colors">Home</a>
              </li>
              <li>
                <a href="#services" className="hover:text-blue-400 transition-colors">Services</a>
              </li>
              <li>
                <a href="#process" className="hover:text-blue-400 transition-colors">How It Works</a>
              </li>
              <li>
                <a href="#proof" className="hover:text-blue-400 transition-colors">Payment Proof &amp; Reviews</a>
              </li>
              <li>
                <a href="#contact" className="hover:text-blue-400 transition-colors">Contact Numbers</a>
              </li>
              <li>
                <a href="#faq" className="hover:text-blue-400 transition-colors">FAQ</a>
              </li>
            </ul>
          </div>

          {/* Contact Details Col */}
          <div className="lg:col-span-4 space-y-4">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">Direct Calling Lines</h4>
            <div className="space-y-3">
              <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-slate-400 block text-[11px]">Primary Calling Number:</span>
                  <span className="text-white font-bold font-mono text-sm">+91 7888870589</span>
                </div>
                <a
                  href="tel:+917888870589"
                  onClick={() => trackPhoneCall('+91 7888870589', 'Primary', 'Footer Call L1')}
                  className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center gap-1 active:scale-95 transition-all"
                  aria-label="Call +917888870589"
                >
                  <Phone className="w-3 h-3" />
                  <span>Call L1</span>
                </a>
              </div>

              <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-slate-400 block text-[11px]">Secondary Support Line:</span>
                  <span className="text-white font-bold font-mono text-sm">+91 8847415750</span>
                </div>
                <a
                  href="tel:+918847415750"
                  onClick={() => trackPhoneCall('+91 8847415750', 'Secondary', 'Footer Call L2')}
                  className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs flex items-center gap-1 active:scale-95 transition-all"
                  aria-label="Call +918847415750"
                >
                  <Phone className="w-3 h-3" />
                  <span>Call L2</span>
                </a>
              </div>

              <div>
                <span className="text-slate-400 block text-xs mb-1">Official Telegram Chat:</span>
                <a
                  href="https://t.me/Angad_ads"
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => trackTelegramClick('Footer Telegram Link')}
                  className="text-blue-400 hover:underline inline-flex items-center gap-1 font-medium text-xs sm:text-sm"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>https://t.me/Angad_ads</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          </div>

        </div>

        {/* Legal & Compliance Notice Row */}
        <div className="py-8 space-y-4">
          <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-900 text-xs text-slate-400 flex items-start gap-3 leading-relaxed">
            <ShieldAlert className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-slate-300">Official Disclaimer:</strong>{' '}
              Angad Ads ek independent advertising service hai aur Meta Platforms, Inc. se officially affiliated ya endorsed nahi hai.
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
            <div>
              &copy; {new Date().getFullYear()} ANGAD ADS. All rights reserved.
            </div>

            <div className="flex items-center gap-6">
              <button
                type="button"
                onClick={() => onOpenLegal('privacy')}
                className="hover:text-blue-400 transition-colors underline-offset-4 hover:underline"
              >
                Privacy Policy
              </button>
              <button
                type="button"
                onClick={() => onOpenLegal('terms')}
                className="hover:text-blue-400 transition-colors underline-offset-4 hover:underline"
              >
                Terms of Service
              </button>
            </div>
          </div>
        </div>

      </div>
    </footer>
  );
};
