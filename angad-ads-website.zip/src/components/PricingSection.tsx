import React from 'react';
import { Send, ArrowUpRight, CheckCircle2, ShieldAlert, Sparkles, Wallet, BookOpen, Target, MessageSquare } from 'lucide-react';
import { trackTelegramClick } from '../utils/pixel';

export const PricingSection: React.FC = () => {
  const benefits = [
    {
      title: 'Affordable Service Options',
      description: 'Har business aur individual ke budget ke according flexible aur practical pricing options.',
      icon: <Wallet className="w-5 h-5 text-emerald-400" />,
    },
    {
      title: 'Beginner-Friendly Guidance',
      description: 'Agar aap pehli baar ads seekh rahe hain, toh simple Hinglish mein step-by-step guidance.',
      icon: <BookOpen className="w-5 h-5 text-blue-400" />,
    },
    {
      title: 'Business-Focused Campaign Setup',
      description: 'Faltu clicks ke bajaye aapke actual products, services aur leads par focused campaign strategy.',
      icon: <Target className="w-5 h-5 text-indigo-400" />,
    },
    {
      title: 'Clear Discussion Before Starting',
      description: 'Kaam shuru karne se pehle scope, timeline aur service fee par 100% transparent discussion.',
      icon: <MessageSquare className="w-5 h-5 text-violet-400" />,
    },
  ];

  return (
    <section className="py-20 bg-[#040815]/50 relative z-10 border-y border-slate-800/70 cinematic-section-reveal">
      {/* Background glow */}
      <div className="absolute top-1/2 right-1/4 -translate-y-1/2 w-96 h-96 bg-blue-600/10 blur-[120px] pointer-events-none -z-10" />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="text-xs font-semibold tracking-wider uppercase text-emerald-400 bg-emerald-950/50 border border-emerald-500/20 px-3 py-1 rounded-md inline-block mb-3">
            TRANSPARENT &amp; ACCESSIBLE
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mb-4 text-balance">
            Professional Ads Support — Budget Ke According
          </h2>
          <p className="text-base sm:text-lg text-slate-300 leading-relaxed text-balance">
            Setup service ho ya Ads seekhne ki guidance, apni requirement aur budget batayein. Affordable pricing options discuss karein.
          </p>
        </div>

        {/* 4 Benefits Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-10">
          {benefits.map((b) => (
            <div
              key={b.title}
              className="p-6 rounded-2xl glass-card glass-card-hover flex flex-col justify-between"
            >
              <div>
                <div className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center mb-4">
                  {b.icon}
                </div>
                <h3 className="text-base font-bold text-white mb-2">{b.title}</h3>
                <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                  {b.description}
                </p>
              </div>

              <div className="mt-5 pt-3 border-t border-slate-800/80 flex items-center gap-1.5 text-xs text-emerald-400 font-medium">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Verified Approach</span>
              </div>
            </div>
          ))}
        </div>

        {/* Pricing Disclosure Box & Action Card */}
        <div className="rounded-2xl bg-gradient-to-br from-slate-900/90 via-[#0b1329] to-slate-900/90 border border-slate-700/80 p-6 sm:p-8 flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl">
          <div className="space-y-2 text-center md:text-left max-w-xl">
            <div className="inline-flex items-center gap-2 text-xs font-semibold text-blue-400">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Custom Quote Based On Scope</span>
            </div>
            <h4 className="text-xl font-bold text-white">
              Har Business Ke Liye Fair &amp; Transparent Pricing
            </h4>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Hum koi fixed fabricated rate ya hidden fees quote nahi karte. Setup ka scope, target locations aur training sessions ki zarurat samajhkar exact price share ki jayegi.
            </p>
          </div>

          <div className="shrink-0">
            <a
              href="https://t.me/Angad_ads"
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => trackTelegramClick('Pricing Section CTA')}
              className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl font-bold text-sm text-white bg-gradient-to-r from-blue-600 via-indigo-600 to-violet-600 hover:from-blue-500 hover:to-violet-500 shadow-xl shadow-blue-600/30 transition-all duration-200 active:scale-95 group"
            >
              <Send className="w-4 h-4 text-blue-200 group-hover:translate-x-0.5 transition-transform" />
              <span>Price Jaanne Ke Liye Contact Karein</span>
              <ArrowUpRight className="w-4 h-4 text-blue-200 opacity-80" />
            </a>
          </div>
        </div>

      </div>
    </section>
  );
};
