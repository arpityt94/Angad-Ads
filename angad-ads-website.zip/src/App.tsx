/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { CinematicBackground } from './components/CinematicBackground';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Services } from './components/Services';
import { LearnOrSetupSection } from './components/LearnOrSetupSection';
import { PricingSection } from './components/PricingSection';
import { LeadGenSection } from './components/LeadGenSection';
import { WhyChooseUs } from './components/WhyChooseUs';
import { HowItWorks } from './components/HowItWorks';
import { ProofGallery } from './components/ProofGallery';
import { Industries } from './components/Industries';
import { FAQ } from './components/FAQ';
import { ContactSection } from './components/ContactSection';
import { FinalCTA } from './components/FinalCTA';
import { Footer } from './components/Footer';
import { MobileContactBar } from './components/MobileContactBar';
import { CallModal } from './components/CallModal';
import { LegalModal } from './components/LegalModal';

export default function App() {
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [callModalOpen, setCallModalOpen] = useState(false);
  const [legalTab, setLegalTab] = useState<'privacy' | 'terms' | null>(null);

  const isAnyModalActive = lightboxOpen || callModalOpen || legalTab !== null;

  useEffect(() => {
    const elements = document.querySelectorAll('.cinematic-section-reveal');
    if (!('IntersectionObserver' in window)) {
      elements.forEach((el) => el.classList.add('is-visible'));
      return;
    }

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.08, rootMargin: '0px 0px -40px 0px' }
    );

    elements.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  return (
    <div className="min-h-screen bg-[#02040a] text-slate-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white relative isolate">
      
      {/* 5-Layer Cinematic Lightning, Atmospheric Fog & Drifting Particle Background */}
      <CinematicBackground />

      {/* Top Navbar */}
      <Navbar />

      {/* Main Content Sections */}
      <main className="flex-1 relative z-10">
        {/* Hero with Electric-Blue Light Sweep & Floating Glass Dashboard */}
        <Hero onOpenCallModal={() => setCallModalOpen(true)} />

        {/* 6 Core Offerings: Setup Karwao, Seekho, Lead Gen, FB & Insta, Optimization, Guidance */}
        <Services />

        {/* Learn Or Get It Done: 2 Side-by-Side Large Cards */}
        <LearnOrSetupSection />

        {/* Affordable Pricing Section: Budget Ke According */}
        <PricingSection />

        {/* Lead Generation Specialty Section */}
        <LeadGenSection onOpenCallModal={() => setCallModalOpen(true)} />

        {/* Strategic Benefits & Planning */}
        <WhyChooseUs />

        {/* 4-Step Working Timeline */}
        <HowItWorks />

        {/* 20 Verified Payment Proofs & Genuine Client Feedback */}
        <ProofGallery onLightboxChange={setLightboxOpen} />

        {/* Eligible Business Categories */}
        <Industries />

        {/* Frequently Asked Questions */}
        <FAQ />

        {/* Dedicated Contact Numbers Section */}
        <ContactSection />

        {/* Final Conversion Action Banner */}
        <FinalCTA onOpenCallModal={() => setCallModalOpen(true)} />
      </main>

      {/* Comprehensive Footer with Both Numbers */}
      <Footer onOpenLegal={(tab) => setLegalTab(tab)} />

      {/* Sticky Mobile Contact Bar & Desktop Floating Telegram */}
      <MobileContactBar
        hidden={isAnyModalActive}
        onOpenCallModal={() => setCallModalOpen(true)}
      />

      {/* Call Selection Modal for Two Direct Calling Lines */}
      <CallModal
        isOpen={callModalOpen}
        onClose={() => setCallModalOpen(false)}
      />

      {/* Legal Modals for Privacy Policy & Terms of Service */}
      {legalTab && (
        <LegalModal
          initialTab={legalTab}
          onClose={() => setLegalTab(null)}
        />
      )}

    </div>
  );
}
